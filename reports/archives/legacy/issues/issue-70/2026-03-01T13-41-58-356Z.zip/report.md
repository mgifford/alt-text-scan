# Scan Report: Italy

- Issue: https://github.com/mgifford/alt-text-scan/issues/70
- Submitted by: mgifford
- Scanned at: 2026-03-01T13:41:09.580Z
- Engines used: All engines (AXE, ALFA, Equal Access, AccessLint, QualWeb)
- Scan duration: 14.4 minutes
- Total URLs submitted: 68
- Accepted public URLs: 68
- Rejected URLs: 0
- ALFA outcomes: 46897 passed, 6219 failed, 701 cantTell, 3499 inapplicable
- axe outcomes: 39717 passed, 588 failed, 634 cantTell, 3517 inapplicable
- Equal Access outcomes: 127155 passed, 2728 failed (2288 unique, 440 duplicate), 2346 cantTell, 0 inapplicable
- AccessLint outcomes: 5447 passed, 809 failed (809 unique, 0 duplicate), 0 cantTell, 0 inapplicable
- QualWeb outcomes: 16338 passed, 2579 failed, 9937 cantTell, 132 inapplicable
- Duplicate findings caught by later scanners: 7921

## 🎯 Priority: Pages with Most Errors

Focus your efforts on these pages to make the biggest impact (combined scanner unique failures):

| Page | axe Unique | ALFA Unique | Equal Access Unique | AccessLint Unique | QualWeb | Total Unique | Page Title |
|---|---:|---:|---:|---:|---:|---:|---|
| [View Page](https://www.governo.it/it/i-ministeri-0) | 10 | 19 | 35 | 56 | 100 | **220** | I Ministeri \| www.governo.it |
| [View Page](https://www.governo.it/it/comitati-commissioni-e-commissari) | 11 | 17 | 32 | 13 | 139 | **212** | Comitati, Commissioni e Commissari \| www.governo.it |
| [View Page](https://www.governo.it/it/organizzazione/uffici-dipartimenti-strutture/69) | 11 | 16 | 38 | 13 | 129 | **207** | Uffici, dipartimenti, strutture \| www.governo.it |
| [View Page](https://www.governo.it/it/i-governi-dal-1943-ad-oggi/i-governi-nelle-legislature/192) | 8 | 15 | 37 | 10 | 121 | **191** | I Governi nelle Legislature \| www.governo.it |
| [View Page](https://www.governo.it/it/ministri-e-sottosegretari) | 12 | 17 | 31 | 14 | 89 | **163** | Vice Presidenti, Ministri e Sottosegretari \| www.governo.it |
| [View Page](https://www.governo.it/it/il-presidente) | 11 | 25 | 45 | 13 | 60 | **154** | Il Presidente \| www.governo.it |
| [View Page](https://www.governo.it/it/il-governo) | 11 | 19 | 38 | 12 | 52 | **132** | Il Governo \| www.governo.it |
| [View Page](https://www.governo.it/it/la-presidenza-del-consiglio-dei-ministri) | 11 | 18 | 36 | 12 | 55 | **132** | La Presidenza del Consiglio dei Ministri \| www.governo.it |
| [View Page](https://www.governo.it/it) | 9 | 22 | 42 | 12 | 43 | **128** | www.governo.it \| Governo Italiano Presidenza del Consiglio dei Ministri |
| [View Page](https://www.governo.it/it/piano-mattei) | 17 | 22 | 36 | 15 | 38 | **128** | Piano Mattei per l'Africa \| www.governo.it |

## 🔧 Priority: Most Common Issues (ALFA)

These ALFA accessibility issues appear most frequently across your pages:

| Rule | Pages Affected | Documentation |
|---|---:|---|
| [SIA-R11](https://alfa.siteimprove.com/rules/sia-r11): Button elements have an accessible name | **67** of 68 | [View Rule](https://alfa.siteimprove.com/rules/sia-r11) |
| [SIA-R111](https://alfa.siteimprove.com/rules/sia-r111): Interactive elements have a sufficient target size | **67** of 68 | [View Rule](https://alfa.siteimprove.com/rules/sia-r111) |
| [SIA-R53](https://alfa.siteimprove.com/rules/sia-r53): Headings follow a logical hierarchy | **67** of 68 | [View Rule](https://alfa.siteimprove.com/rules/sia-r53) |
| [SIA-R57](https://alfa.siteimprove.com/rules/sia-r57): Landmarks don't repeat the same content | **67** of 68 | [View Rule](https://alfa.siteimprove.com/rules/sia-r57) |
| [SIA-R66](https://alfa.siteimprove.com/rules/sia-r66): Text has enhanced contrast with its background | **67** of 68 | [View Rule](https://alfa.siteimprove.com/rules/sia-r66) |
| [SIA-R69](https://alfa.siteimprove.com/rules/sia-r69): Text has sufficient contrast with its background | **67** of 68 | [View Rule](https://alfa.siteimprove.com/rules/sia-r69) |
| [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72) | **67** of 68 | [View Rule](https://alfa.siteimprove.com/rules/sia-r72) |
| [SIA-R73](https://alfa.siteimprove.com/rules/sia-r73): Text spacing can be adjusted without loss of content | **67** of 68 | [View Rule](https://alfa.siteimprove.com/rules/sia-r73) |
| [SIA-R78](https://alfa.siteimprove.com/rules/sia-r78): Headings of same level have text content between them | **67** of 68 | [View Rule](https://alfa.siteimprove.com/rules/sia-r78) |
| [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84) | **67** of 68 | [View Rule](https://alfa.siteimprove.com/rules/sia-r84) |

> 💡 **Tip**: Click on the rule documentation links to learn how to fix each issue.


## 🔧 Priority: Most Common Issues (axe)

These axe accessibility issues appear most frequently across your pages:

| Rule | Pages Affected | Documentation |
|---|---:|---|
| region | **68** of 68 | [View Rule](https://dequeuniversity.com/rules/axe/4.11.1/region) |
| color-contrast | **67** of 68 | [View Rule](https://dequeuniversity.com/rules/axe/4.11.1/color-contrast) |
| heading-order | **67** of 68 | [View Rule](https://dequeuniversity.com/rules/axe/4.11.1/heading-order) |
| label-title-only | **67** of 68 | [View Rule](https://dequeuniversity.com/rules/axe/4.11.1/label-title-only) |
| link-name | **67** of 68 | [View Rule](https://dequeuniversity.com/rules/axe/4.11.1/link-name) |
| link-in-text-block | **27** of 68 | [View Rule](https://dequeuniversity.com/rules/axe/4.11.1/link-in-text-block) |
| image-alt | **13** of 68 | [View Rule](https://dequeuniversity.com/rules/axe/4.11.1/image-alt) |
| landmark-unique | **11** of 68 | [View Rule](https://dequeuniversity.com/rules/axe/4.11.1/landmark-unique) |
| frame-title | **5** of 68 | [View Rule](https://dequeuniversity.com/rules/axe/4.11.1/frame-title) |
| image-redundant-alt | **1** of 68 | [View Rule](https://dequeuniversity.com/rules/axe/4.11.1/image-redundant-alt) |

> 💡 **Tip**: Click on the rule documentation links to learn how to fix each issue. Consider fixing the most common issues first for maximum impact.

> 🤖 **Future Enhancement**: This report will soon include AI-powered fix suggestions for authenticated GitHub users (opt-in only, no auto-run AI).

## 🔍 Cross-Page Patterns: Common HTML Issues

These HTML patterns cause the same accessibility errors across multiple pages. **Fix the pattern once in your codebase to fix it everywhere!**

### 🎯 Top Patterns to Fix (Highest Impact)

#### Pattern 1: Affects 67 page(s) - 419 occurrence(s)

**Scanner**: ALFA
**Rule**: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)
**Issue**: The line height of the paragraph is less than 1.5

**HTML Pattern**:
```html
<p>...</p>
```

**XPath** (use in browser DevTools):
```
/p
```

**How to Replicate**:
1. Open any affected page in your browser
2. Press F12 to open DevTools
3. Go to Console tab
4. Run: `$x('/p')`
5. The element will be highlighted

**Affected Pages**:
- https://governo.it/
- https://governo.it/en
- https://governo.it/it
- https://governo.it/pubblicit%C3%A0-legale
- https://governo.it/it/agenda
- *...and 62 more page(s)*

---

#### Pattern 2: Affects 67 page(s) - 67 occurrence(s)

**Scanner**: ALFA
**Rule**: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)
**Issue**: The link does not have an accessible name

**HTML Pattern**:
```html
<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>
```

**XPath** (use in browser DevTools):
```
/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]
```

**How to Replicate**:
1. Open any affected page in your browser
2. Press F12 to open DevTools
3. Go to Console tab
4. Run: `$x('/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]')`
5. The element will be highlighted

**Affected Pages**:
- https://governo.it/
- https://governo.it/en
- https://governo.it/it
- https://governo.it/pubblicit%C3%A0-legale
- https://governo.it/it/agenda
- *...and 62 more page(s)*

---

#### Pattern 3: Affects 67 page(s) - 67 occurrence(s)

**Scanner**: ALFA
**Rule**: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)
**Issue**: Target has insufficient size

**HTML Pattern**:
```html
<a href="https://www.governo.it">IT</a>
```

**XPath** (use in browser DevTools):
```
/a
```

**How to Replicate**:
1. Open any affected page in your browser
2. Press F12 to open DevTools
3. Go to Console tab
4. Run: `$x('/a')`
5. The element will be highlighted

**Affected Pages**:
- https://governo.it/
- https://governo.it/en
- https://governo.it/it
- https://governo.it/pubblicit%C3%A0-legale
- https://governo.it/it/agenda
- *...and 62 more page(s)*

---

#### Pattern 4: Affects 67 page(s) - 67 occurrence(s)

**Scanner**: ALFA
**Rule**: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)
**Issue**: Target has insufficient size

**HTML Pattern**:
```html
<a href="https://www.governo.it/en">EN</a>
```

**XPath** (use in browser DevTools):
```
/a
```

**How to Replicate**:
1. Open any affected page in your browser
2. Press F12 to open DevTools
3. Go to Console tab
4. Run: `$x('/a')`
5. The element will be highlighted

**Affected Pages**:
- https://governo.it/
- https://governo.it/en
- https://governo.it/it
- https://governo.it/pubblicit%C3%A0-legale
- https://governo.it/it/agenda
- *...and 62 more page(s)*

---

#### Pattern 5: Affects 67 page(s) - 67 occurrence(s)

**Scanner**: ALFA
**Rule**: [SIA-R72: No description](https://alfa.siteimprove.com/rules/sia-r72)
**Issue**: The text of the paragraph is uppercased

**HTML Pattern**:
```html
<p class="menu_under_burger">MENU</p>
```

**XPath** (use in browser DevTools):
```
/p[@class="menu_under_burger"]
```

**How to Replicate**:
1. Open any affected page in your browser
2. Press F12 to open DevTools
3. Go to Console tab
4. Run: `$x('/p[@class="menu_under_burger"]')`
5. The element will be highlighted

**Affected Pages**:
- https://governo.it/
- https://governo.it/en
- https://governo.it/it
- https://governo.it/pubblicit%C3%A0-legale
- https://governo.it/it/agenda
- *...and 62 more page(s)*

---

#### Pattern 6: Affects 67 page(s) - 67 occurrence(s)

**Scanner**: ALFA
**Rule**: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)
**Issue**: The line height of the paragraph is less than 1.5

**HTML Pattern**:
```html
<p class="menu_under_burger">MENU</p>
```

**XPath** (use in browser DevTools):
```
/p[@class="menu_under_burger"]
```

**How to Replicate**:
1. Open any affected page in your browser
2. Press F12 to open DevTools
3. Go to Console tab
4. Run: `$x('/p[@class="menu_under_burger"]')`
5. The element will be highlighted

**Affected Pages**:
- https://governo.it/
- https://governo.it/en
- https://governo.it/it
- https://governo.it/pubblicit%C3%A0-legale
- https://governo.it/it/agenda
- *...and 62 more page(s)*

---

#### Pattern 7: Affects 67 page(s) - 67 occurrence(s)

**Scanner**: ALFA
**Rule**: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)
**Issue**: The line height of the paragraph is less than 1.5

**HTML Pattern**:
```html
<p class="nav_social clearfix">...</p>
```

**XPath** (use in browser DevTools):
```
/p[@class="nav_social clearfix"]
```

**How to Replicate**:
1. Open any affected page in your browser
2. Press F12 to open DevTools
3. Go to Console tab
4. Run: `$x('/p[@class="nav_social clearfix"]')`
5. The element will be highlighted

**Affected Pages**:
- https://governo.it/
- https://governo.it/en
- https://governo.it/it
- https://governo.it/pubblicit%C3%A0-legale
- https://governo.it/it/agenda
- *...and 62 more page(s)*

---

#### Pattern 8: Affects 67 page(s) - 67 occurrence(s)

**Scanner**: ALFA
**Rule**: [SIA-R84: No description](https://alfa.siteimprove.com/rules/sia-r84)
**Issue**: The scrollable element is not reachable through keyboard navigation

**HTML Pattern**:
```html
<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>
```

**XPath** (use in browser DevTools):
```
/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]
```

**How to Replicate**:
1. Open any affected page in your browser
2. Press F12 to open DevTools
3. Go to Console tab
4. Run: `$x('/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]')`
5. The element will be highlighted

**Affected Pages**:
- https://governo.it/
- https://governo.it/en
- https://governo.it/it
- https://governo.it/pubblicit%C3%A0-legale
- https://governo.it/it/agenda
- *...and 62 more page(s)*

---

#### Pattern 9: Affects 67 page(s) - 67 occurrence(s)

**Scanner**: axe
**Rule**: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious
**Issue**: Elements must meet minimum color contrast ratio thresholds

**HTML Pattern**:
```html
<strong> Privacy policy</strong>
```

**XPath** (use in browser DevTools):
```
u > strong
```

**How to Replicate**:
1. Open any affected page in your browser
2. Press F12 to open DevTools
3. Go to Console tab
4. Run: `$x('u > strong')`
5. The element will be highlighted

**Affected Pages**:
- https://governo.it/
- https://governo.it/en
- https://governo.it/it
- https://governo.it/pubblicit%C3%A0-legale
- https://governo.it/it/agenda
- *...and 62 more page(s)*

---

#### Pattern 10: Affects 67 page(s) - 67 occurrence(s)

**Scanner**: axe
**Rule**: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious
**Issue**: Links must have discernible text

**HTML Pattern**:
```html
<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">
                        <div class="bar"></div>
                        <div class="bar"></div>
                        <div class="bar"></div>
                    </a>
```

**XPath** (use in browser DevTools):
```
.toggle-menu
```

**How to Replicate**:
1. Open any affected page in your browser
2. Press F12 to open DevTools
3. Go to Console tab
4. Run: `$x('.toggle-menu')`
5. The element will be highlighted

**Affected Pages**:
- https://governo.it/
- https://governo.it/en
- https://governo.it/it
- https://governo.it/pubblicit%C3%A0-legale
- https://governo.it/it/agenda
- *...and 62 more page(s)*

---

#### Pattern 11: Affects 67 page(s) - 67 occurrence(s)

**Scanner**: axe
**Rule**: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate
**Issue**: All page content should be contained by landmarks

**HTML Pattern**:
```html
<p>
```

**XPath** (use in browser DevTools):
```
#popup-text > p
```

**How to Replicate**:
1. Open any affected page in your browser
2. Press F12 to open DevTools
3. Go to Console tab
4. Run: `$x('#popup-text > p')`
5. The element will be highlighted

**Affected Pages**:
- https://governo.it/
- https://governo.it/en
- https://governo.it/it
- https://governo.it/pubblicit%C3%A0-legale
- https://governo.it/it/agenda
- *...and 62 more page(s)*

---

#### Pattern 12: Affects 67 page(s) - 67 occurrence(s)

**Scanner**: axe
**Rule**: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate
**Issue**: All page content should be contained by landmarks

**HTML Pattern**:
```html
<p id="skip-link">
        <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>
        <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>
    </p>
```

**XPath** (use in browser DevTools):
```
#skip-link
```

**How to Replicate**:
1. Open any affected page in your browser
2. Press F12 to open DevTools
3. Go to Console tab
4. Run: `$x('#skip-link')`
5. The element will be highlighted

**Affected Pages**:
- https://governo.it/
- https://governo.it/en
- https://governo.it/it
- https://governo.it/pubblicit%C3%A0-legale
- https://governo.it/it/agenda
- *...and 62 more page(s)*

---

#### Pattern 13: Affects 66 page(s) - 66 occurrence(s)

**Scanner**: ALFA
**Rule**: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)
**Issue**: Target has insufficient size

**HTML Pattern**:
```html
<a href="https://www.facebook.com/palazzochigi.it/" title="Seguici su Facebook">...</a>
```

**XPath** (use in browser DevTools):
```
/a
```

**How to Replicate**:
1. Open any affected page in your browser
2. Press F12 to open DevTools
3. Go to Console tab
4. Run: `$x('/a')`
5. The element will be highlighted

**Affected Pages**:
- https://governo.it/
- https://governo.it/it
- https://governo.it/pubblicit%C3%A0-legale
- https://governo.it/it/agenda
- https://governo.it/it/agenda?t_p=h
- *...and 61 more page(s)*

---

#### Pattern 14: Affects 66 page(s) - 66 occurrence(s)

**Scanner**: ALFA
**Rule**: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)
**Issue**: Target has insufficient size

**HTML Pattern**:
```html
<a href="https://twitter.com/Palazzo_Chigi" title="Seguici su Twitter">...</a>
```

**XPath** (use in browser DevTools):
```
/a
```

**How to Replicate**:
1. Open any affected page in your browser
2. Press F12 to open DevTools
3. Go to Console tab
4. Run: `$x('/a')`
5. The element will be highlighted

**Affected Pages**:
- https://governo.it/
- https://governo.it/it
- https://governo.it/pubblicit%C3%A0-legale
- https://governo.it/it/agenda
- https://governo.it/it/agenda?t_p=h
- *...and 61 more page(s)*

---

#### Pattern 15: Affects 66 page(s) - 66 occurrence(s)

**Scanner**: ALFA
**Rule**: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)
**Issue**: Target has insufficient size

**HTML Pattern**:
```html
<a href="https://www.instagram.com/palazzo_chigi/" title="Seguici su Instagram">...</a>
```

**XPath** (use in browser DevTools):
```
/a
```

**How to Replicate**:
1. Open any affected page in your browser
2. Press F12 to open DevTools
3. Go to Console tab
4. Run: `$x('/a')`
5. The element will be highlighted

**Affected Pages**:
- https://governo.it/
- https://governo.it/it
- https://governo.it/pubblicit%C3%A0-legale
- https://governo.it/it/agenda
- https://governo.it/it/agenda?t_p=h
- *...and 61 more page(s)*

---

> 💡 **Pro Tip**: These patterns likely come from shared components or templates in your codebase. Fix them in the component/template source, and the fix will propagate to all affected pages.

## 📊 Detailed Results

Complete scan results for all tested pages:

| Submitted URL | Final URL | Status | HTTP | Redirected | Time (ms) | axe Unique | ALFA Unique | Equal Access Unique | AccessLint Unique | Duplicates | Notes |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| https://governo.it/ | https://www.governo.it/it | OK | 200 | yes | 18084 | 9 | 22 | 42 | 12 | 152 | www.governo.it \| Governo Italiano Presidenza del Consiglio dei Ministri |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R2 (HTML elements have a valid lang attribute), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, image-alt, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, img_alt_valid, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, text_quoted_correctly, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name, text-alternatives/img-alt |
| https://governo.it/en | https://www.governo.it/en | OK | 200 | yes | 13052 | 9 | 18 | 37 | 12 | 92 | www.governo.it \| Governo Italiano Presidenza del Consiglio dei Ministri |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R2 (HTML elements have a valid lang attribute), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, image-alt, image-redundant-alt, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, img_alt_redundant, img_alt_valid, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, text_sensory_misuse, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name, text-alternatives/image-redundant-alt, text-alternatives/img-alt |
| https://governo.it/it | https://www.governo.it/it | OK | 200 | yes | 13265 | 9 | 22 | 40 | 12 | 152 | www.governo.it \| Governo Italiano Presidenza del Consiglio dei Ministri |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R2 (HTML elements have a valid lang attribute), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, image-alt, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, img_alt_valid, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, text_quoted_correctly, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name, text-alternatives/img-alt |
| https://governo.it/pubblicit%C3%A0-legale | https://www.governo.it/it/pubblicit%C3%A0-legale | OK | 200 | yes | 13765 | 6 | 17 | 30 | 10 | 112 | Pubblicità Legale \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, heading_markup_misuse, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/empty-table-header, distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/feed/rss | https://www.governo.it/feed/rss | OK | 200 | yes | 5656 | 5 | 5 | 5 | 6 | 0 |  |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R1 (id attributes are unique within the document), SIA-R4 (Page has a descriptive title), SIA-R59, SIA-R79, SIA-R87 (First focusable element is a skip link) |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: document-title, html-has-lang, landmark-one-main, page-has-heading-one, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: html_lang_exists, html_skipnav_exists, page_title_exists, skip_main_exists, style_highcontrast_visible |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: landmarks/landmark-main, landmarks/region, navigable/bypass, navigable/document-title, navigable/page-has-heading-one, readable/html-has-lang |
| https://governo.it/it/agenda | https://www.governo.it/it/agenda | OK | 200 | yes | 21301 | 7 | 16 | 34 | 10 | 113 | Agenda \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, aria_form_label_unique, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/agenda?t_p=h | https://www.governo.it/it/agenda?t_p=h | OK | 200 | yes | 21335 | 7 | 17 | 34 | 10 | 113 | Agenda \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, aria_form_label_unique, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/archivio-articoli-presidenza-del-consiglio | https://www.governo.it/it/archivio-articoli-presidenza-del-consiglio | OK | 200 | yes | 13496 | 6 | 14 | 28 | 10 | 142 | Notizie dalla Presidenza del Consiglio \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, text_quoted_correctly, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/empty-table-header, distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/archivio-consiglio-dei-ministri | https://www.governo.it/it/archivio-consiglio-dei-ministri | OK | 200 | yes | 14253 | 6 | 17 | 26 | 10 | 150 | Riunioni del Consiglio dei Ministri \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/empty-table-header, distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/campagne-di-comunicazione | https://www.governo.it/it/campagne-di-comunicazione | OK | 200 | yes | 13880 | 6 | 16 | 47 | 10 | 129 | Campagne di Comunicazione della XIX Legislatura \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/empty-table-header, distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/come-fare | https://www.governo.it/it/come-fare | OK | 200 | yes | 11115 | 7 | 15 | 31 | 10 | 74 | Come fare per \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, blockquote_cite_exists, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/comitati-commissioni-e-commissari | https://www.governo.it/it/comitati-commissioni-e-commissari | OK | 200 | yes | 13677 | 11 | 17 | 32 | 13 | 316 | Comitati, Commissioni e Commissari \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, distinguishable/link-in-text-block, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/dichiarazioneaccessibilita | https://www.governo.it/it/dichiarazioneaccessibilita | OK | 200 | yes | 10940 | 10 | 17 | 31 | 12 | 79 | Dichiarazione di accessibilità \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R62 (Links are visually distinguishable from surrounding text), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, distinguishable/link-in-text-block, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/diretta-video | https://www.governo.it/it/diretta-video | OK | 200 | yes | 12954 | 11 | 19 | 36 | 13 | 84 | Diretta Video \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R13, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, frame-title, heading-order, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, frame_src_valid, frame_title_exists, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, text_quoted_correctly, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/frame-title, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/gallerie-del-presidente | https://www.governo.it/it/gallerie-del-presidente | OK | 200 | yes | 13997 | 6 | 17 | 44 | 10 | 129 | Il Presidente del Consiglio: gallerie foto e video \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/empty-table-header, distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/palazzo-chigi-la-storia-le-immagini-e-il-restauro/palazzo-chigi-la-storia/2877 | https://www.governo.it/it/palazzo-chigi-la-storia-le-immagini-e-il-restauro/palazzo-chigi-la-storia/2877 | OK | 200 | yes | 12288 | 10 | 15 | 34 | 11 | 131 | Palazzo Chigi, la storia \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R56 (Landmarks with the same role are distinguishable), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, landmark-unique, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, aria_navigation_label_unique, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/articolo/il-messaggio-del-presidente-meloni-all-evento-ia-e-lavoro-governare-la-trasformazione | https://www.governo.it/it/articolo/il-messaggio-del-presidente-meloni-all-evento-ia-e-lavoro-governare-la-trasformazione | OK | 200 | yes | 11671 | 10 | 17 | 38 | 12 | 77 | Il messaggio del Presidente Meloni all’evento "IA e lavoro: governare la trasformazione, moltiplicare le opportunità. Strategie, fiducia, regole, competenze" \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R2 (HTML elements have a valid lang attribute), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R61, SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, image-alt, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, img_alt_valid, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, text_quoted_correctly, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name, text-alternatives/img-alt |
| https://governo.it/it/gallerie | https://www.governo.it/it/gallerie | OK | 200 | yes | 13419 | 6 | 16 | 44 | 10 | 128 | Gallerie foto e video \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/empty-table-header, distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/articolo/la-facciata-di-palazzo-chigi-si-illumina-il-quarto-anniversario-dellinvasione-dellucraina | https://www.governo.it/it/articolo/la-facciata-di-palazzo-chigi-si-illumina-il-quarto-anniversario-dellinvasione-dellucraina | OK | 200 | yes | 11545 | 8 | 16 | 36 | 11 | 77 | La facciata di Palazzo Chigi si illumina per il quarto anniversario dell'invasione dell'Ucraina \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R13, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, frame-title, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, frame_src_valid, frame_title_exists, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/frame-title, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/pubblicita-legale | https://www.governo.it/it/pubblicita-legale | OK | 200 | yes | 12679 | 6 | 15 | 27 | 10 | 141 | Pubblicità Legale \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, heading_markup_misuse, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/empty-table-header, distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/media/campagna-di-comunicazione-istituzionale-il-treno-del-ricordo-2026/31082 | https://www.governo.it/it/media/campagna-di-comunicazione-istituzionale-il-treno-del-ricordo-2026/31082 | OK | 200 | yes | 12158 | 8 | 18 | 34 | 11 | 80 | Campagna di comunicazione istituzionale “Il Treno del Ricordo 2026" \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R13, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: aria-prohibited-attr, button-name, color-contrast, frame-title, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, frame_src_valid, frame_title_exists, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/frame-title, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/media/la-facciata-di-palazzo-chigi-si-illumina-il-quarto-anniversario-dellinvasione-dellucraina-0 | https://www.governo.it/it/media/la-facciata-di-palazzo-chigi-si-illumina-il-quarto-anniversario-dellinvasione-dellucraina-0 | OK | 200 | yes | 12563 | 8 | 15 | 32 | 11 | 77 | La facciata di Palazzo Chigi si illumina per il quarto anniversario dell'invasione dell'Ucraina \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R13, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, frame-title, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, frame_src_valid, frame_title_exists, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/frame-title, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/provvedimenti | https://www.governo.it/it/provvedimenti | OK | 200 | yes | 12284 | 7 | 18 | 27 | 11 | 109 | I provvedimenti del Consiglio dei Ministri \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, heading_markup_misuse, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/empty-table-header, distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/tipologie-contenuto/notizie | https://www.governo.it/it/tipologie-contenuto/notizie | OK | 200 | yes | 13028 | 7 | 17 | 28 | 11 | 142 | Notizie \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/empty-table-header, distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/media/la-facciata-di-palazzo-chigi-si-illumina-il-quarto-anniversario-dellinvasione-dellucraina | https://www.governo.it/it/media/la-facciata-di-palazzo-chigi-si-illumina-il-quarto-anniversario-dellinvasione-dellucraina | OK | 200 | yes | 11972 | 7 | 14 | 29 | 10 | 77 | La facciata di Palazzo Chigi si illumina per il quarto anniversario dell'invasione dell'Ucraina \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/governo/meloni/presidente-del-consiglio/giorgia-meloni | https://www.governo.it/it/governo/meloni/presidente-del-consiglio/giorgia-meloni | OK | 200 | yes | 11541 | 9 | 14 | 38 | 11 | 79 | Giorgia Meloni \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, blockquote_cite_exists, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/notizie-governo | https://www.governo.it/it/notizie-governo | OK | 200 | yes | 13449 | 6 | 15 | 29 | 10 | 139 | Il Governo: notizie \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/empty-table-header, distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/organizzazione/il-segretario-generale/64 | https://www.governo.it/it/organizzazione/il-segretario-generale/64 | OK | 200 | yes | 11508 | 10 | 15 | 34 | 11 | 98 | Il Segretario generale \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R56 (Landmarks with the same role are distinguishable), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, landmark-unique, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, aria_navigation_label_unique, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/il-governo-funzioni-struttura-e-storia/la-funzione-del-presidente-del-consiglio/188 | https://www.governo.it/it/il-governo-funzioni-struttura-e-storia/la-funzione-del-presidente-del-consiglio/188 | OK | 200 | yes | 11377 | 10 | 15 | 34 | 11 | 87 | La funzione del Presidente del Consiglio \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R56 (Landmarks with the same role are distinguishable), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, landmark-unique, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, aria_navigation_label_unique, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/articolo/incidente-milano-il-cordoglio-del-presidente-meloni/31213 | https://www.governo.it/it/articolo/incidente-milano-il-cordoglio-del-presidente-meloni/31213 | OK | 200 | yes | 11529 | 10 | 16 | 36 | 12 | 78 | Incidente a Milano, il cordoglio del Presidente Meloni \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R2 (HTML elements have a valid lang attribute), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, image-alt, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, img_alt_valid, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name, text-alternatives/img-alt |
| https://governo.it/it/il-presidente | https://www.governo.it/it/il-presidente | OK | 200 | yes | 14000 | 11 | 25 | 45 | 13 | 183 | Il Presidente \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R62 (Links are visually distinguishable from surrounding text), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84, SIA-R85 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, heading_content_exists, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, text_quoted_correctly, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/empty-heading, navigable/heading-order, navigable/link-name |
| https://governo.it/it/notizie-presidente | https://www.governo.it/it/notizie-presidente | OK | 200 | yes | 13484 | 6 | 14 | 26 | 10 | 137 | Il Presidente del Consiglio: notizie \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/empty-table-header, distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/organizzazione/uffici-dipartimenti-strutture/69 | https://www.governo.it/it/organizzazione/uffici-dipartimenti-strutture/69 | OK | 200 | yes | 13275 | 11 | 16 | 38 | 13 | 303 | Uffici, dipartimenti, strutture \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R56 (Landmarks with the same role are distinguishable), SIA-R57 (Landmarks don't repeat the same content), SIA-R62 (Links are visually distinguishable from surrounding text), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, landmark-unique, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, aria_navigation_label_unique, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, heading_markup_misuse, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, distinguishable/link-in-text-block, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/articolo/giorno-del-ricordo-dal-10-febbraio-al-1-marzo-2026-la-3a-edizione-del-treno-del-ricordo | https://www.governo.it/it/articolo/giorno-del-ricordo-dal-10-febbraio-al-1-marzo-2026-la-3a-edizione-del-treno-del-ricordo | OK | 200 | yes | 12046 | 8 | 18 | 34 | 11 | 80 | Giorno del Ricordo, dal 10 febbraio al 1° marzo 2026 la 3a edizione del “Treno del Ricordo” \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R2 (HTML elements have a valid lang attribute), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, image-alt, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, img_alt_valid, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name, text-alternatives/img-alt |
| https://governo.it/it/visitare-i-palazzi-istituzionali/prenotazione-visite-guidate/2939 | https://www.governo.it/it/visitare-i-palazzi-istituzionali/prenotazione-visite-guidate/2939 | OK | 200 | yes | 12306 | 10 | 15 | 39 | 11 | 96 | Le visite guidate \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R56 (Landmarks with the same role are distinguishable), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, landmark-unique, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, aria_navigation_label_unique, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, text_quoted_correctly, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/agenda/2026-03-04t000000/laying-groundwork-jobs-africa/31205 | https://www.governo.it/it/agenda/2026-03-04t000000/laying-groundwork-jobs-africa/31205 | OK | 200 | yes | 10830 | 7 | 14 | 32 | 10 | 73 | Laying the Groundwork for Jobs in Africa \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, text_quoted_correctly, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/piano-mattei | https://www.governo.it/it/piano-mattei | OK | 200 | yes | 12686 | 17 | 22 | 36 | 15 | 125 | Piano Mattei per l'Africa \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R56 (Landmarks with the same role are distinguishable), SIA-R57 (Landmarks don't repeat the same content), SIA-R61, SIA-R62 (Links are visually distinguishable from surrounding text), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, landmark-unique, link-in-text-block, link-name, listitem, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, aria_navigation_label_unique, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, heading_markup_misuse, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, text_quoted_correctly, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/listitem-parent, distinguishable/color-contrast, distinguishable/link-in-text-block, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/i-ministeri-0 | https://www.governo.it/it/i-ministeri-0 | OK | 200 | yes | 14653 | 10 | 19 | 35 | 56 | 262 | I Ministeri \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R62 (Links are visually distinguishable from surrounding text), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, distinguishable/link-in-text-block, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/media/incontro-con-il-presidente-della-repubblica-di-cipro/31198 | https://www.governo.it/it/media/incontro-con-il-presidente-della-repubblica-di-cipro/31198 | OK | 200 | yes | 16027 | 12 | 17 | 44 | 14 | 90 | Incontro con il Presidente della Repubblica di Cipro \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R13, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, frame-title, heading-order, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, frame_src_valid, frame_title_exists, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/frame-title, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/articolo/consiglio-dei-ministri-n-163/31194 | https://www.governo.it/it/articolo/consiglio-dei-ministri-n-163/31194 | OK | 200 | yes | 11998 | 8 | 17 | 37 | 11 | 78 | Consiglio dei Ministri n. 163 \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R2 (HTML elements have a valid lang attribute), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, image-alt, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, img_alt_valid, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name, text-alternatives/img-alt |
| https://governo.it/it/ministri-e-sottosegretari | https://www.governo.it/it/ministri-e-sottosegretari | OK | 200 | yes | 14548 | 12 | 17 | 31 | 14 | 321 | Vice Presidenti, Ministri e Sottosegretari \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/articolo/tre-anni-di-governo-meloni-tre-anni-di-risultati-e-traguardi-l-italia/30114 | https://www.governo.it/it/articolo/tre-anni-di-governo-meloni-tre-anni-di-risultati-e-traguardi-l-italia/30114 | OK | 200 | yes | 11519 | 10 | 16 | 34 | 12 | 79 | Tre anni di Governo Meloni, tre anni di risultati e traguardi per l’Italia \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R2 (HTML elements have a valid lang attribute), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, image-alt, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, img_alt_valid, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name, text-alternatives/img-alt |
| https://governo.it/it/costituzione-italiana/principi-fondamentali/2839 | https://www.governo.it/it/costituzione-italiana/principi-fondamentali/2839 | OK | 200 | yes | 11399 | 10 | 17 | 35 | 13 | 106 | Principi fondamentali \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R56 (Landmarks with the same role are distinguishable), SIA-R57 (Landmarks don't repeat the same content), SIA-R62 (Links are visually distinguishable from surrounding text), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, landmark-unique, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, aria_navigation_label_unique, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, distinguishable/link-in-text-block, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/media/corinaldo-incontro-con-i-familiari-delle-vittime-palazzo-chigi/31211 | https://www.governo.it/it/media/corinaldo-incontro-con-i-familiari-delle-vittime-palazzo-chigi/31211 | OK | 200 | yes | 11922 | 7 | 14 | 32 | 10 | 78 | Corinaldo, incontro con i familiari delle vittime a Palazzo Chigi \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/agenda/2026-03-06t000000/cerimonia-di-apertura-dei-giochi-paralimpici-invernali-di-milano-cortina | https://www.governo.it/it/agenda/2026-03-06t000000/cerimonia-di-apertura-dei-giochi-paralimpici-invernali-di-milano-cortina | OK | 200 | yes | 10862 | 7 | 14 | 31 | 10 | 73 | Cerimonia di Apertura dei Giochi Paralimpici Invernali di Milano Cortina 2026 \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/media/giorno-del-ricordo-dal-10-febbraio-al-1-marzo-2026-la-3a-edizione-del-treno-del-ricordo/31177 | https://www.governo.it/it/media/giorno-del-ricordo-dal-10-febbraio-al-1-marzo-2026-la-3a-edizione-del-treno-del-ricordo/31177 | OK | 200 | yes | 12510 | 7 | 14 | 29 | 10 | 77 | Giorno del Ricordo, dal 10 febbraio al 1° marzo 2026 la 3a edizione del “Treno del Ricordo” \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/media/cerimonia-di-chiusura-dei-giochi-olimpici-invernali-di-milano-cortina-2026/31175 | https://www.governo.it/it/media/cerimonia-di-chiusura-dei-giochi-olimpici-invernali-di-milano-cortina-2026/31175 | OK | 200 | yes | 11925 | 9 | 15 | 30 | 11 | 81 | Cerimonia di Chiusura dei Giochi Olimpici Invernali di Milano Cortina 2026 \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/il-governo | https://www.governo.it/it/il-governo | OK | 200 | yes | 14267 | 11 | 19 | 38 | 12 | 173 | Il Governo \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R56 (Landmarks with the same role are distinguishable), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, landmark-unique, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, aria_navigation_label_unique, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/agenda/2026-02-27t000000/voto-alle-donne/31206 | https://www.governo.it/it/agenda/2026-02-27t000000/voto-alle-donne/31206 | OK | 200 | yes | 10810 | 7 | 15 | 32 | 10 | 72 | Voto alle donne \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, text_quoted_correctly, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/media/riunione-della-coalizione-dei-volenterosi/31181 | https://www.governo.it/it/media/riunione-della-coalizione-dei-volenterosi/31181 | OK | 200 | yes | 11682 | 9 | 14 | 30 | 11 | 81 | Riunione della Coalizione dei volenterosi \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/media/incontro-con-il-presidente-della-repubblica-di-cipro/31200 | https://www.governo.it/it/media/incontro-con-il-presidente-della-repubblica-di-cipro/31200 | OK | 200 | yes | 12137 | 9 | 15 | 33 | 11 | 82 | Incontro con il Presidente della Repubblica di Cipro \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/il-governo-funzioni-struttura-e-storia/la-struttura-del-governo/185 | https://www.governo.it/it/il-governo-funzioni-struttura-e-storia/la-struttura-del-governo/185 | OK | 200 | yes | 11211 | 8 | 15 | 33 | 10 | 83 | Il Governo \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R56 (Landmarks with the same role are distinguishable), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, landmark-unique, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, aria_navigation_label_unique, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/privacy-policy | https://www.governo.it/it/privacy-policy | OK | 200 | yes | 11558 | 17 | 16 | 32 | 19 | 122 | Privacy policy \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R62 (Links are visually distinguishable from surrounding text), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, list_markup_review, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, distinguishable/link-in-text-block, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/tipologie-contenuto/consiglio-dei-ministri | https://www.governo.it/it/tipologie-contenuto/consiglio-dei-ministri | OK | 200 | yes | 13350 | 7 | 17 | 29 | 11 | 149 | Consiglio dei Ministri \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/empty-table-header, distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/i-governi-dal-1943-ad-oggi/i-governi-nelle-legislature/192 | https://www.governo.it/it/i-governi-dal-1943-ad-oggi/i-governi-nelle-legislature/192 | OK | 200 | yes | 13486 | 8 | 15 | 37 | 10 | 282 | I Governi nelle Legislature \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R56 (Landmarks with the same role are distinguishable), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, landmark-unique, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, aria_navigation_label_unique, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/note-legali | https://www.governo.it/it/note-legali | OK | 200 | yes | 11595 | 13 | 16 | 31 | 15 | 97 | Note legali \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R62 (Links are visually distinguishable from surrounding text), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, distinguishable/link-in-text-block, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/agenda/2026-03-04t000000/incontro-con-il-ministro-degli-esteri-degli-emirati-arabi-uniti/31207 | https://www.governo.it/it/agenda/2026-03-04t000000/incontro-con-il-ministro-degli-esteri-degli-emirati-arabi-uniti/31207 | OK | 200 | yes | 10977 | 7 | 14 | 31 | 10 | 73 | Incontro con il ministro degli Esteri degli Emirati Arabi Uniti \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/articolo/corinaldo-incontro-con-i-familiari-delle-vittime-palazzo-chigi/31212 | https://www.governo.it/it/articolo/corinaldo-incontro-con-i-familiari-delle-vittime-palazzo-chigi/31212 | OK | 200 | yes | 11252 | 8 | 16 | 35 | 11 | 75 | Corinaldo, incontro con i familiari delle vittime a Palazzo Chigi \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R2 (HTML elements have a valid lang attribute), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, image-alt, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, img_alt_valid, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, text_quoted_correctly, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name, text-alternatives/img-alt |
| https://governo.it/it/articolo/g7-leaders-statement-war-ukraine/31186 | https://www.governo.it/it/articolo/g7-leaders-statement-war-ukraine/31186 | OK | 200 | yes | 11924 | 10 | 16 | 34 | 12 | 77 | G7 leaders’ statement on the war in Ukraine \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R2 (HTML elements have a valid lang attribute), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, image-alt, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, img_alt_valid, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, text_sensory_misuse, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name, text-alternatives/img-alt |
| https://governo.it/it/la-presidenza-del-consiglio-dei-ministri | https://www.governo.it/it/la-presidenza-del-consiglio-dei-ministri | OK | 200 | yes | 12835 | 11 | 18 | 36 | 12 | 149 | La Presidenza del Consiglio dei Ministri \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R56 (Landmarks with the same role are distinguishable), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, landmark-unique, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, aria_navigation_label_unique, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, text_quoted_correctly, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/articolo/medio-oriente-il-presidente-meloni-presiede-una-conferenza-telefonica/31215 | https://www.governo.it/it/articolo/medio-oriente-il-presidente-meloni-presiede-una-conferenza-telefonica/31215 | OK | 200 | yes | 11158 | 10 | 16 | 33 | 12 | 77 | Medio Oriente, il Presidente Meloni presiede una conferenza telefonica \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R2 (HTML elements have a valid lang attribute), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, image-alt, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, img_alt_valid, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name, text-alternatives/img-alt |
| https://governo.it/it/notizie-presidenza | https://www.governo.it/it/notizie-presidenza | OK | 200 | yes | 14122 | 6 | 14 | 34 | 10 | 143 | Notizie dalla Presidenza del Consiglio \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, text_quoted_correctly, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/empty-table-header, distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/notizie-chigi | https://www.governo.it/it/notizie-chigi | OK | 200 | yes | 13684 | 6 | 16 | 29 | 10 | 139 | Notizie da Palazzo Chigi \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/empty-table-header, distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/interventi | https://www.governo.it/it/interventi | OK | 200 | yes | 13211 | 6 | 14 | 30 | 10 | 91 | Interventi del Presidente del Consiglio \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, text_quoted_correctly, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/empty-table-header, distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/sala-stampa | https://www.governo.it/it/sala-stampa | OK | 200 | yes | 11467 | 12 | 17 | 35 | 14 | 86 | Sala stampa \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R62 (Links are visually distinguishable from surrounding text), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-in-text-block, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, distinguishable/link-in-text-block, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/gallerie-governo | https://www.governo.it/it/gallerie-governo | OK | 200 | yes | 13610 | 6 | 16 | 47 | 10 | 129 | Governo: gallerie foto e video \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R113, SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: adaptable/empty-table-header, distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name |
| https://governo.it/it/articolo/il-messaggio-del-presidente-meloni-lanniversario-della-costituzione-di-confetra/31195 | https://www.governo.it/it/articolo/il-messaggio-del-presidente-meloni-lanniversario-della-costituzione-di-confetra/31195 | OK | 200 | yes | 11213 | 8 | 17 | 32 | 11 | 72 | Il messaggio del Presidente Meloni per l'anniversario della costituzione di Confetra \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R2 (HTML elements have a valid lang attribute), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R61, SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R74, SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, image-alt, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, img_alt_valid, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name, text-alternatives/img-alt |
| https://governo.it/it/articolo/il-sottosegretario-mantovano-partecipa-allinaugurazione-dell-anno-giudiziario-della-corte | https://www.governo.it/it/articolo/il-sottosegretario-mantovano-partecipa-allinaugurazione-dell-anno-giudiziario-della-corte | OK | 200 | yes | 11295 | 8 | 16 | 32 | 11 | 70 | Il Sottosegretario Mantovano partecipa all'inaugurazione dell’anno giudiziario della Corte dei conti \| www.governo.it |
|  |  |  |  |  |  |  |  |  |  | ALFA failed rules: SIA-R11 (Button elements have an accessible name), SIA-R111 (Interactive elements have a sufficient target size), SIA-R2 (HTML elements have a valid lang attribute), SIA-R53 (Headings follow a logical hierarchy), SIA-R57 (Landmarks don't repeat the same content), SIA-R66 (Text has enhanced contrast with its background), SIA-R69 (Text has sufficient contrast with its background), SIA-R72, SIA-R73 (Text spacing can be adjusted without loss of content), SIA-R78 (Headings of same level have text content between them), SIA-R83 (Text can be resized to 200% without loss of content), SIA-R84 |
|  |  |  |  |  |  |  |  |  |  | axe failed rules: color-contrast, heading-order, image-alt, label-title-only, link-name, region |
|  |  |  |  |  |  |  |  |  |  | Equal Access failed rules: a_text_purpose, aria_complementary_labelled, aria_content_in_landmark, element_attribute_deprecated, element_tabbable_unobscured, element_tabbable_visible, img_alt_valid, input_label_visible, style_color_misuse, style_highcontrast_visible, text_block_heading, text_contrast_sufficient, widget_tabbable_exists |
|  |  |  |  |  |  |  |  |  |  | AccessLint failed rules: distinguishable/color-contrast, labels-and-names/label-title-only, landmarks/region, navigable/heading-order, navigable/link-name, text-alternatives/img-alt |

## Detailed Failure Information (ALFA)

### https://governo.it/

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: The link does not have an accessible name
- HTML: `<a href="">...</a>`
- XPath: `/a`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

**Failure 3:**
- Message: Target has insufficient size
- HTML: `<a class="vai_alla_notizia" href="https://www.governo.it/it/articolo/medio-oriente-il-presidente-meloni-presiede-una-nuova-riunione-palazzo-chigi/31217" title="Continua a leggere">...</a>`
- XPath: `/a[@class="vai_alla_notizia"]`

#### Rule: [SIA-R2: HTML elements have a valid lang attribute](https://alfa.siteimprove.com/rules/sia-r2)

**Failure 1:**
- Message: The image does not have an accessible name
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/field/image/h_20260228_6.jpg?itok=P9rqZJ9u" class="class_img_url_immagine" />`
- XPath: `/img[@class="class_img_url_immagine"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="tipologia_home_pp">28 Febbraio 2026</p>`
- XPath: `/p[@class="tipologia_home_pp"]`

**Failure 5:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h3 pull-right">...</p>`
- XPath: `/p[@class="h3 pull-right"]`

*... and 2 more failures for this rule*

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3>Incontro con il Presidente della Repubblica di Cip...</h3>`
- XPath: `/h3`

**Failure 2:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/en

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: The link does not have an accessible name
- HTML: `<a href="">...</a>`
- XPath: `/a`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a class="vai_alla_notizia" href="https://www.governo.it/en/articolo/middle-east-president-meloni-chairs-meeting-palazzo-chigi/31220" title="Read more">...</a>`
- XPath: `/a[@class="vai_alla_notizia"]`

#### Rule: [SIA-R2: HTML elements have a valid lang attribute](https://alfa.siteimprove.com/rules/sia-r2)

**Failure 1:**
- Message: The image does not have an accessible name
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/field/image/h_20260228_6.jpg?itok=P9rqZJ9u" class="class_img_url_immagine" />`
- XPath: `/img[@class="class_img_url_immagine"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contacts</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="tipologia_home_pp">28 February 2026</p>`
- XPath: `/p[@class="tipologia_home_pp"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3>Meeting with the President of the Republic of Cypr...</h3>`
- XPath: `/h3`

**Failure 2:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contacts</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: The link does not have an accessible name
- HTML: `<a href="">...</a>`
- XPath: `/a`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

**Failure 3:**
- Message: Target has insufficient size
- HTML: `<a class="vai_alla_notizia" href="https://www.governo.it/it/articolo/medio-oriente-il-presidente-meloni-presiede-una-nuova-riunione-palazzo-chigi/31217" title="Continua a leggere">...</a>`
- XPath: `/a[@class="vai_alla_notizia"]`

#### Rule: [SIA-R2: HTML elements have a valid lang attribute](https://alfa.siteimprove.com/rules/sia-r2)

**Failure 1:**
- Message: The image does not have an accessible name
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/field/image/h_20260228_6.jpg?itok=P9rqZJ9u" class="class_img_url_immagine" />`
- XPath: `/img[@class="class_img_url_immagine"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="tipologia_home_pp">28 Febbraio 2026</p>`
- XPath: `/p[@class="tipologia_home_pp"]`

**Failure 5:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h3 pull-right">...</p>`
- XPath: `/p[@class="h3 pull-right"]`

*... and 2 more failures for this rule*

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3>Incontro con il Presidente della Repubblica di Cip...</h3>`
- XPath: `/h3`

**Failure 2:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/pubblicit%C3%A0-legale

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<button type="button" class="agree-button eu-cookie-compliance-secondary-button">Si, acconsento</button>`
- XPath: `/button[@class="agree-button eu-cookie-compliance-secondary-button"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<button type="button" class="decline-button eu-cookie-compliance-default-button">No, non acconsento</button>`
- XPath: `/button[@class="decline-button eu-cookie-compliance-default-button"]`

**Failure 3:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 4:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">...</a>`
- XPath: `/a`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a title="Vai a pagina 2" href="/it/pubblicit%C3%A0-legale?page=1">2</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/feed/rss

#### Rule: [SIA-R1: id attributes are unique within the document](https://alfa.siteimprove.com/rules/sia-r1)

**Failure 1:**
- Message: The document does not have a `<title>` element

#### Rule: [SIA-R4: Page has a descriptive title](https://alfa.siteimprove.com/rules/sia-r4)

**Failure 1:**
- Message: The `lang` attribute is either missing, empty, or only whitespace
- HTML: `<html>...</html>`
- XPath: `/html`

#### Rule: [SIA-R59](https://alfa.siteimprove.com/rules/sia-r59)

**Failure 1:**
- Message: The document does not have a heading element

#### Rule: [SIA-R79](https://alfa.siteimprove.com/rules/sia-r79)

**Failure 1:**
- Message: The element has no <figure> ancestor and has text which not inside a <code>, <kbd> or <samp> element.
- HTML: `<pre style="word-wrap: break-word; white-space: pre-wrap;"><?xml version="1.0" encoding="utf-8" ?><rss versio...</pre>`
- XPath: `/pre`

#### Rule: [SIA-R87: First focusable element is a skip link](https://alfa.siteimprove.com/rules/sia-r87)

**Failure 1:**
- Message: The document has no tabbable descendants

### https://governo.it/it/agenda

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<button type="submit" name="m_m" value="1772364805" class="btn-link bottone_agenda_all">Febbraio 2026</button>`
- XPath: `/button[@class="btn-link bottone_agenda_all"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="agenda_titolo_vedi_tutto" style="font-weight: bold;">...</p>`
- XPath: `/p[@class="agenda_titolo_vedi_tutto"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/agenda?t_p=h

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

**Failure 3:**
- Message: Target has insufficient size
- HTML: `<button type="submit" name="m_m" value="1772366458" class="btn-link bottone_agenda_all">Febbraio 2026</button>`
- XPath: `/button[@class="btn-link bottone_agenda_all"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="agenda_titolo_vedi_tutto" style="font-weight: bold;">...</p>`
- XPath: `/p[@class="agenda_titolo_vedi_tutto"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/archivio-articoli-presidenza-del-consiglio

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a title="Vai a pagina 2" href="/it/archivio-articoli-presidenza-del-consiglio?page=1">2</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/archivio-consiglio-dei-ministri

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<button type="button" class="agree-button eu-cookie-compliance-secondary-button">Si, acconsento</button>`
- XPath: `/button[@class="agree-button eu-cookie-compliance-secondary-button"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<button type="button" class="decline-button eu-cookie-compliance-default-button">No, non acconsento</button>`
- XPath: `/button[@class="decline-button eu-cookie-compliance-default-button"]`

**Failure 3:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

**Failure 4:**
- Message: Target has insufficient size
- HTML: `<a class="box_text_anchor" href="/it/articolo/consiglio-dei-ministri-n-163/31194">...</a>`
- XPath: `/a[@class="box_text_anchor"]`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a title="Vai a pagina 2" href="/it/archivio-consiglio-dei-ministri?page=1">2</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/campagne-di-comunicazione

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a title="Vai a pagina 2" href="/it/campagne-di-comunicazione?page=1">2</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h6">Video                    </p>`
- XPath: `/p[@class="h6"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h2 class="h4">Campagna di comunicazione istituzionale “Rete lavo...</h2>`
- XPath: `/h2[@class="h4"]`

**Failure 2:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/come-fare

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="/it/come-fare" title="" class="active-trail active">Come fare per</a>`
- XPath: `/a[@class="active-trail active"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/comitati-commissioni-e-commissari

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: The link does not have an accessible name
- HTML: `<a href="https://presidenza.governo.it/AmministrazioneTrasparente/Organizzazione/CommissariStraordinari/DPR_20250113_Castelli.pdf"> </a>`
- XPath: `/a`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a href="https://presidenza.governo.it/AmministrazioneTrasparente/Organizzazione/CommissariStraordinari/DPCM%203%20febbraio%202025.pdf">4</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/dichiarazioneaccessibilita

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

**Failure 3:**
- Message: Target has insufficient size
- HTML: `<a href="/it/dichiarazioneaccessibilita" title="" class="active-trail active">Dichiarazione di accessibilità</a>`
- XPath: `/a[@class="active-trail active"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R62: Links are visually distinguishable from surrounding text](https://alfa.siteimprove.com/rules/sia-r62)

**Failure 1:**
- Message: The link is not distinguishable from the surrounding text
- HTML: `<a href="mailto:accessibile@governo.it">accessibile@governo.it</a>`
- XPath: `/a`

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/diretta-video

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R13](https://alfa.siteimprove.com/rules/sia-r13)

**Failure 1:**
- Message: The `<iframe>` does not have an accessible name
- HTML: `<iframe width="1232" height="693" src="https://www.youtube.com/embed/bm77mn8H5SI" frameborder="0" allowfullscreen="" />`
- XPath: `/iframe`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3>Gli altri video</h3>`
- XPath: `/h3`

**Failure 2:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h3 pull-right">...</p>`
- XPath: `/p[@class="h3 pull-right"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3>Medio Oriente, il Presidente Meloni presiede una n...</h3>`
- XPath: `/h3`

**Failure 2:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/gallerie-del-presidente

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">...</a>`
- XPath: `/a`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a title="Vai a pagina 2" href="/it/gallerie-del-presidente?page=1">2</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h6">Foto                    </p>`
- XPath: `/p[@class="h6"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h2 class="h4">Anniversario dei Patti Lateranensi e della Revisio...</h2>`
- XPath: `/h2[@class="h4"]`

**Failure 2:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/palazzo-chigi-la-storia-le-immagini-e-il-restauro/palazzo-chigi-la-storia/2877

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R56: Landmarks with the same role are distinguishable](https://alfa.siteimprove.com/rules/sia-r56)

**Failure 1:**
- Message: Some `navigation` have the same name.

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/articolo/il-messaggio-del-presidente-meloni-all-evento-ia-e-lavoro-governare-la-trasformazione

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R2: HTML elements have a valid lang attribute](https://alfa.siteimprove.com/rules/sia-r2)

**Failure 1:**
- Message: The image does not have an accessible name
- HTML: `<img class="width_100" src="https://www.governo.it/sites/governo.it/files/PresidenteMeloni%20%283%29.jpg" />`
- XPath: `/img[@class="width_100"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R61](https://alfa.siteimprove.com/rules/sia-r61)

**Failure 1:**
- Message: The document does not start with a level 1 heading

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h6">Venerdì, 27 Febbraio 2026</p>`
- XPath: `/p[@class="h6"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/gallerie

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a title="Vai a pagina 2" href="/it/gallerie?page=1">2</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h6">Foto                    </p>`
- XPath: `/p[@class="h6"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h2 class="h4">Giorno del Ricordo, dal 10 febbraio al 1° marzo 20...</h2>`
- XPath: `/h2[@class="h4"]`

**Failure 2:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/articolo/la-facciata-di-palazzo-chigi-si-illumina-il-quarto-anniversario-dellinvasione-dellucraina

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R13](https://alfa.siteimprove.com/rules/sia-r13)

**Failure 1:**
- Message: The `<iframe>` does not have an accessible name
- HTML: `<iframe frameborder="0" src="https://www.youtube-nocookie.com/embed/uRX9orLmugk? width%3D640%26amp%3Bheight%3D360%26amp%3Bautoplay%3D0%26amp%3Bvq%3Dlarge%26amp%3Brel%3D0%26amp%3Bcontrols%3D1%26amp%3Bautohide%3D2%26amp%3Bshowinfo%3D1%26amp%3Bmodestbranding%3D0%26amp%3Btheme%3Ddark%26amp%3Biv_load_policy%3D1%26amp%3Bwmode%3Dopaque" id="fitvid257477" />`
- XPath: `/iframe[@id="fitvid257477"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h5 dataright">24 Febbraio 2026</p>`
- XPath: `/p[@class="h5 dataright"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/pubblicita-legale

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a title="Vai a pagina 2" href="/it/pubblicita-legale?page=1">2</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/media/campagna-di-comunicazione-istituzionale-il-treno-del-ricordo-2026/31082

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<button type="button" class="agree-button eu-cookie-compliance-secondary-button">Si, acconsento</button>`
- XPath: `/button[@class="agree-button eu-cookie-compliance-secondary-button"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<button type="button" class="decline-button eu-cookie-compliance-default-button">No, non acconsento</button>`
- XPath: `/button[@class="decline-button eu-cookie-compliance-default-button"]`

**Failure 3:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 4:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">...</a>`
- XPath: `/a`

#### Rule: [SIA-R13](https://alfa.siteimprove.com/rules/sia-r13)

**Failure 1:**
- Message: The `<iframe>` does not have an accessible name
- HTML: `<iframe class="" width="640" height="360" src="//www.youtube-nocookie.com/embed/PXnHCjDifgU?width%3D640%26amp%3Bheight%3D360%26amp%3Btheme%3Ddark%26amp%3Bautoplay%3D0%26amp%3Bvq%3Dlarge%26amp%3Brel%3D0%26amp%3Bshowinfo%3D1%26amp%3Bmodestbranding%3D0%26amp%3Biv_load_policy%3D1%26amp%3Bcontrols%3D1%26amp%3Bautohide%3D2%26amp%3Bwmode%3Dopaque" frameborder="0" allowfullscreen="" />`
- XPath: `/iframe`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/media/la-facciata-di-palazzo-chigi-si-illumina-il-quarto-anniversario-dellinvasione-dellucraina-0

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R13](https://alfa.siteimprove.com/rules/sia-r13)

**Failure 1:**
- Message: The `<iframe>` does not have an accessible name
- HTML: `<iframe class="" width="640" height="360" src="//www.youtube-nocookie.com/embed/uRX9orLmugk?width%3D640%26amp%3Bheight%3D360%26amp%3Btheme%3Ddark%26amp%3Bautoplay%3D0%26amp%3Bvq%3Dlarge%26amp%3Brel%3D0%26amp%3Bshowinfo%3D1%26amp%3Bmodestbranding%3D0%26amp%3Biv_load_policy%3D1%26amp%3Bcontrols%3D1%26amp%3Bautohide%3D2%26amp%3Bwmode%3Dopaque" frameborder="0" allowfullscreen="" />`
- XPath: `/iframe`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/provvedimenti

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a title="Vai a pagina 2" href="/it/provvedimenti?page=1">2</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="h4">DECRETO LEGGE: Disposizioni urgenti per la proroga...</h3>`
- XPath: `/h3[@class="h4"]`

**Failure 2:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h4 text-center" style="word-wrap: break-word; margin-left: 30%; padding-top: 1.5%;">...</p>`
- XPath: `/p[@class="h4 text-center"]`

**Failure 5:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h5">Data Consiglio dei Ministri: 29 Dicembre 2025</p>`
- XPath: `/p[@class="h5"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="h4">DECRETO LEGISLATIVO: Attuazione della direttiva (U...</h3>`
- XPath: `/h3[@class="h4"]`

**Failure 2:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/tipologie-contenuto/notizie

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a title="Vai a pagina 2" href="/it/tipologie-contenuto/notizie?page=1">2</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="h4">...</h3>`
- XPath: `/h3[@class="h4"]`

**Failure 2:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h4 text-center" style="word-wrap: break-word; margin-left: 30%; padding-top: 1.5%;">...</p>`
- XPath: `/p[@class="h4 text-center"]`

**Failure 5:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h5">28 Febbraio 2026</p>`
- XPath: `/p[@class="h5"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/media/la-facciata-di-palazzo-chigi-si-illumina-il-quarto-anniversario-dellinvasione-dellucraina

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/governo/meloni/presidente-del-consiglio/giorgia-meloni

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/notizie-governo

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a class="box_text_anchor" href="/it/articolo/consiglio-dei-ministri-n-163/31194">...</a>`
- XPath: `/a[@class="box_text_anchor"]`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a title="Vai a pagina 2" href="/it/notizie-governo?page=1">2</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/organizzazione/il-segretario-generale/64

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R56: Landmarks with the same role are distinguishable](https://alfa.siteimprove.com/rules/sia-r56)

**Failure 1:**
- Message: Some `navigation` have the same name.

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/il-governo-funzioni-struttura-e-storia/la-funzione-del-presidente-del-consiglio/188

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R56: Landmarks with the same role are distinguishable](https://alfa.siteimprove.com/rules/sia-r56)

**Failure 1:**
- Message: Some `navigation` have the same name.

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/articolo/incidente-milano-il-cordoglio-del-presidente-meloni/31213

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R2: HTML elements have a valid lang attribute](https://alfa.siteimprove.com/rules/sia-r2)

**Failure 1:**
- Message: The image does not have an accessible name
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/BD8E879E_PP.jpg?itok=NuB9_Mmu" />`
- XPath: `/img`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h5 dataright">27 Febbraio 2026</p>`
- XPath: `/p[@class="h5 dataright"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/il-presidente

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="/it/il-presidente" title="" class="active-trail active">Il Presidente</a>`
- XPath: `/a[@class="active-trail active"]`

**Failure 3:**
- Message: Target has insufficient size
- HTML: `<a class="simple-link-blu" href="https://www.governo.it/it/governo/meloni/presidente-del-consiglio/giorgia-meloni" title="Biografia">Biografia</a>`
- XPath: `/a[@class="simple-link-blu"]`

**Failure 4:**
- Message: Target has insufficient size
- HTML: `<a class="white_link" href="https://www.governo.it/gallerie-del-presidente" title="Gallerie del Presidente">Vedi Tutto</a>`
- XPath: `/a[@class="white_link"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="h4">...</h3>`
- XPath: `/h3[@class="h4"]`

**Failure 2:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R62: Links are visually distinguishable from surrounding text](https://alfa.siteimprove.com/rules/sia-r62)

**Failure 1:**
- Message: The link is not distinguishable from the surrounding text
- HTML: `<a href="mailto:presidente@pec.governo.it">presidente@pec.governo.it</a>`
- XPath: `/a`

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h3 pull-right">...</p>`
- XPath: `/p[@class="h3 pull-right"]`

**Failure 5:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="agenda_data_giorno_p">...</p>`
- XPath: `/p[@class="agenda_data_giorno_p"]`

*... and 2 more failures for this rule*

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3>Medio Oriente, il Presidente Meloni presiede una n...</h3>`
- XPath: `/h3`

**Failure 2:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

#### Rule: [SIA-R85](https://alfa.siteimprove.com/rules/sia-r85)

**Failure 1:**
- Message: The text of the paragraph is all italic
- HTML: `<p class="data_intervista">Venerdì, 27 Febbraio 2026</p>`
- XPath: `/p[@class="data_intervista"]`

### https://governo.it/it/notizie-presidente

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a title="Vai a pagina 2" href="/it/notizie-presidente?page=1">2</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/organizzazione/uffici-dipartimenti-strutture/69

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R56: Landmarks with the same role are distinguishable](https://alfa.siteimprove.com/rules/sia-r56)

**Failure 1:**
- Message: Some `navigation` have the same name.

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R62: Links are visually distinguishable from surrounding text](https://alfa.siteimprove.com/rules/sia-r62)

**Failure 1:**
- Message: The link is not distinguishable from the surrounding text
- HTML: `<a href="http://www.sspa.it/">Scuola Nazionale dell'Amministrazione</a>`
- XPath: `/a`

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/articolo/giorno-del-ricordo-dal-10-febbraio-al-1-marzo-2026-la-3a-edizione-del-treno-del-ricordo

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<button type="button" class="agree-button eu-cookie-compliance-secondary-button">Si, acconsento</button>`
- XPath: `/button[@class="agree-button eu-cookie-compliance-secondary-button"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<button type="button" class="decline-button eu-cookie-compliance-default-button">No, non acconsento</button>`
- XPath: `/button[@class="decline-button eu-cookie-compliance-default-button"]`

**Failure 3:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R2: HTML elements have a valid lang attribute](https://alfa.siteimprove.com/rules/sia-r2)

**Failure 1:**
- Message: The image does not have an accessible name
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/H_IMG_0798.jpg?itok=gEwWwQ8c" />`
- XPath: `/img`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h5 dataright">23 Febbraio 2026</p>`
- XPath: `/p[@class="h5 dataright"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/visitare-i-palazzi-istituzionali/prenotazione-visite-guidate/2939

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R56: Landmarks with the same role are distinguishable](https://alfa.siteimprove.com/rules/sia-r56)

**Failure 1:**
- Message: Some `navigation` have the same name.

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/agenda/2026-03-04t000000/laying-groundwork-jobs-africa/31205

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/piano-mattei

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" title="" class="share_buttons_trigger reveal-trigger" tabindex="-1">...</a>`
- XPath: `/a[@class="share_buttons_trigger reveal-trigger"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<button type="button" class="agree-button eu-cookie-compliance-secondary-button">Si, acconsento</button>`
- XPath: `/button[@class="agree-button eu-cookie-compliance-secondary-button"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<button type="button" class="decline-button eu-cookie-compliance-default-button">No, non acconsento</button>`
- XPath: `/button[@class="decline-button eu-cookie-compliance-default-button"]`

**Failure 3:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 4:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">...</a>`
- XPath: `/a`

**Failure 5:**
- Message: Target has insufficient size
- HTML: `<a class="eventi eventi_no_active" href="/it/articolo/piano-mattei-lafrica-la-cabina-di-regia/28742">La Cabina di Regia</a>`
- XPath: `/a[@class="eventi eventi_no_active"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R56: Landmarks with the same role are distinguishable](https://alfa.siteimprove.com/rules/sia-r56)

**Failure 1:**
- Message: Some `navigation` have the same name.

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R61](https://alfa.siteimprove.com/rules/sia-r61)

**Failure 1:**
- Message: The document does not start with a level 1 heading

#### Rule: [SIA-R62: Links are visually distinguishable from surrounding text](https://alfa.siteimprove.com/rules/sia-r62)

**Failure 1:**
- Message: The link is not distinguishable from the surrounding text
- HTML: `<a href="/node/24851">Vertice Italia-Africa del 29 gennaio 2024</a>`
- XPath: `/a`

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/i-ministeri-0

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: The link does not have an accessible name
- HTML: `<a href="mailto:gabinetto.rapportiparlamento@governo.it%20%20%20">...</a>`
- XPath: `/a`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<button type="button" class="agree-button eu-cookie-compliance-secondary-button">Si, acconsento</button>`
- XPath: `/button[@class="agree-button eu-cookie-compliance-secondary-button"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<button type="button" class="decline-button eu-cookie-compliance-default-button">No, non acconsento</button>`
- XPath: `/button[@class="decline-button eu-cookie-compliance-default-button"]`

**Failure 3:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h4 class="strong">Presidenza del Consiglio dei Ministri</h4>`
- XPath: `/h4[@class="strong"]`

**Failure 2:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R62: Links are visually distinguishable from surrounding text](https://alfa.siteimprove.com/rules/sia-r62)

**Failure 1:**
- Message: The link is not distinguishable from the surrounding text
- HTML: `<a href="mailto:ministro.affariesteri@cert.esteri.it">ministro.affariesteri@cert.esteri.it</a>`
- XPath: `/a`

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/media/incontro-con-il-presidente-della-repubblica-di-cipro/31198

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<button type="button" class="agree-button eu-cookie-compliance-secondary-button">Si, acconsento</button>`
- XPath: `/button[@class="agree-button eu-cookie-compliance-secondary-button"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<button type="button" class="decline-button eu-cookie-compliance-default-button">No, non acconsento</button>`
- XPath: `/button[@class="decline-button eu-cookie-compliance-default-button"]`

**Failure 3:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R13](https://alfa.siteimprove.com/rules/sia-r13)

**Failure 1:**
- Message: The `<iframe>` does not have an accessible name
- HTML: `<iframe class="" width="640" height="360" src="//www.youtube-nocookie.com/embed/A0AMOjcy9LE?width%3D640%26amp%3Bheight%3D360%26amp%3Btheme%3Ddark%26amp%3Bautoplay%3D0%26amp%3Bvq%3Dlarge%26amp%3Brel%3D0%26amp%3Bshowinfo%3D1%26amp%3Bmodestbranding%3D0%26amp%3Biv_load_policy%3D1%26amp%3Bcontrols%3D1%26amp%3Bautohide%3D2%26amp%3Bwmode%3Dopaque" frameborder="0" allowfullscreen="" />`
- XPath: `/iframe`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/articolo/consiglio-dei-ministri-n-163/31194

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R2: HTML elements have a valid lang attribute](https://alfa.siteimprove.com/rules/sia-r2)

**Failure 1:**
- Message: The image does not have an accessible name
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/palazzo_chigi_22_6.jpg?itok=_mAwl-Yw" />`
- XPath: `/img`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h5 dataright">26 Febbraio 2026</p>`
- XPath: `/p[@class="h5 dataright"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/ministri-e-sottosegretari

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h4>Presidente del Consiglio dei Ministri</h4>`
- XPath: `/h4`

**Failure 2:**
- Message: The heading skips one or more levels
- HTML: `<h3 style="margin-bottom: 0px;">Ministro per i Rapporti con il Parlamento</h3>`
- XPath: `/h3`

**Failure 3:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3>Vice Presidente</h3>`
- XPath: `/h3`

**Failure 2:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/articolo/tre-anni-di-governo-meloni-tre-anni-di-risultati-e-traguardi-l-italia/30114

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R2: HTML elements have a valid lang attribute](https://alfa.siteimprove.com/rules/sia-r2)

**Failure 1:**
- Message: The image does not have an accessible name
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/notizia-3-anni.png?itok=pqAVElsr" />`
- XPath: `/img`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h5 dataright">22 Ottobre 2025</p>`
- XPath: `/p[@class="h5 dataright"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/costituzione-italiana/principi-fondamentali/2839

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R56: Landmarks with the same role are distinguishable](https://alfa.siteimprove.com/rules/sia-r56)

**Failure 1:**
- Message: Some `navigation` have the same name.

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R62: Links are visually distinguishable from surrounding text](https://alfa.siteimprove.com/rules/sia-r62)

**Failure 1:**
- Message: The link is not distinguishable from the surrounding text
- HTML: `<a href="#1" title="leggi la nota n.2">1</a>`
- XPath: `/a`

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/media/corinaldo-incontro-con-i-familiari-delle-vittime-palazzo-chigi/31211

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/agenda/2026-03-06t000000/cerimonia-di-apertura-dei-giochi-paralimpici-invernali-di-milano-cortina

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/media/giorno-del-ricordo-dal-10-febbraio-al-1-marzo-2026-la-3a-edizione-del-treno-del-ricordo/31177

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/media/cerimonia-di-chiusura-dei-giochi-olimpici-invernali-di-milano-cortina-2026/31175

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/il-governo

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="/it/il-governo" title="" class="active-trail active">Il Governo</a>`
- XPath: `/a[@class="active-trail active"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h5>...</h5>`
- XPath: `/h5`

**Failure 2:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R56: Landmarks with the same role are distinguishable](https://alfa.siteimprove.com/rules/sia-r56)

**Failure 1:**
- Message: Some `navigation` have the same name.

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h3 pull-right">...</p>`
- XPath: `/p[@class="h3 pull-right"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3>Corinaldo, incontro con i familiari delle vittime ...</h3>`
- XPath: `/h3`

**Failure 2:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/agenda/2026-02-27t000000/voto-alle-donne/31206

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/media/riunione-della-coalizione-dei-volenterosi/31181

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/media/incontro-con-il-presidente-della-repubblica-di-cipro/31200

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/il-governo-funzioni-struttura-e-storia/la-struttura-del-governo/185

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R56: Landmarks with the same role are distinguishable](https://alfa.siteimprove.com/rules/sia-r56)

**Failure 1:**
- Message: Some `navigation` have the same name.

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/privacy-policy

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="/it/privacy-policy" title="" class="active-trail active">Privacy policy</a>`
- XPath: `/a[@class="active-trail active"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R62: Links are visually distinguishable from surrounding text](https://alfa.siteimprove.com/rules/sia-r62)

**Failure 1:**
- Message: The link is not distinguishable from the surrounding text
- HTML: `<a href="https://www.garanteprivacy.it/web/guest/home/docweb/-/docweb-display/docweb/1089924">www.garanteprivacy.it/web/guest/home/docweb/-/docw...</a>`
- XPath: `/a`

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/tipologie-contenuto/consiglio-dei-ministri

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a title="Vai a pagina 2" href="/it/tipologie-contenuto/consiglio-dei-ministri?page=1">2</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="h4">...</h3>`
- XPath: `/h3[@class="h4"]`

**Failure 2:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h4 text-center" style="word-wrap: break-word; margin-left: 30%; padding-top: 1.5%;">...</p>`
- XPath: `/p[@class="h4 text-center"]`

**Failure 5:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h5">26 Febbraio 2026</p>`
- XPath: `/p[@class="h5"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/i-governi-dal-1943-ad-oggi/i-governi-nelle-legislature/192

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R56: Landmarks with the same role are distinguishable](https://alfa.siteimprove.com/rules/sia-r56)

**Failure 1:**
- Message: Some `navigation` have the same name.

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/note-legali

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="/it/note-legali" title="" class="active-trail active">Note legali</a>`
- XPath: `/a[@class="active-trail active"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R62: Links are visually distinguishable from surrounding text](https://alfa.siteimprove.com/rules/sia-r62)

**Failure 1:**
- Message: The link is not distinguishable from the surrounding text
- HTML: `<a href="/it">www.governo.it</a>`
- XPath: `/a`

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/agenda/2026-03-04t000000/incontro-con-il-ministro-degli-esteri-degli-emirati-arabi-uniti/31207

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/articolo/corinaldo-incontro-con-i-familiari-delle-vittime-palazzo-chigi/31212

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R2: HTML elements have a valid lang attribute](https://alfa.siteimprove.com/rules/sia-r2)

**Failure 1:**
- Message: The image does not have an accessible name
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/H_DSC09689.jpg?itok=ogq_xTuw" />`
- XPath: `/img`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h5 dataright">27 Febbraio 2026</p>`
- XPath: `/p[@class="h5 dataright"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/articolo/g7-leaders-statement-war-ukraine/31186

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R2: HTML elements have a valid lang attribute](https://alfa.siteimprove.com/rules/sia-r2)

**Failure 1:**
- Message: The image does not have an accessible name
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/logo_PCM_136.png?itok=mxVl33xN" />`
- XPath: `/img`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h5 dataright">24 Febbraio 2026</p>`
- XPath: `/p[@class="h5 dataright"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/la-presidenza-del-consiglio-dei-ministri

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="/it/la-presidenza-del-consiglio-dei-ministri" title="" class="active-trail active">Presidenza del Consiglio dei Ministri</a>`
- XPath: `/a[@class="active-trail active"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h5>...</h5>`
- XPath: `/h5`

**Failure 2:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R56: Landmarks with the same role are distinguishable](https://alfa.siteimprove.com/rules/sia-r56)

**Failure 1:**
- Message: Some `navigation` have the same name.

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h3 pull-right">...</p>`
- XPath: `/p[@class="h3 pull-right"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/articolo/medio-oriente-il-presidente-meloni-presiede-una-conferenza-telefonica/31215

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R2: HTML elements have a valid lang attribute](https://alfa.siteimprove.com/rules/sia-r2)

**Failure 1:**
- Message: The image does not have an accessible name
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/logo_PCM_128_2.png?itok=HJMSujGB" />`
- XPath: `/img`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h5 dataright">28 Febbraio 2026</p>`
- XPath: `/p[@class="h5 dataright"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/notizie-presidenza

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a title="Vai a pagina 2" href="/it/notizie-presidenza?page=1">2</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/notizie-chigi

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

**Failure 3:**
- Message: Target has insufficient size
- HTML: `<a class="box_text_anchor" href="/it/articolo/consiglio-dei-ministri-n-163/31194">...</a>`
- XPath: `/a[@class="box_text_anchor"]`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a title="Vai a pagina 2" href="/it/notizie-chigi?page=1">2</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/interventi

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a title="Vai a pagina 2" href="/it/interventi?page=1">2</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/sala-stampa

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

**Failure 3:**
- Message: Target has insufficient size
- HTML: `<a href="/it/sala-stampa" title="" class="active-trail active">Sala stampa</a>`
- XPath: `/a[@class="active-trail active"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R62: Links are visually distinguishable from surrounding text](https://alfa.siteimprove.com/rules/sia-r62)

**Failure 1:**
- Message: The link is not distinguishable from the surrounding text
- HTML: `<a href="https://amei.palazzochigi.it">https://amei.palazzochigi.it</a>`
- XPath: `/a`

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/gallerie-governo

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R113](https://alfa.siteimprove.com/rules/sia-r113)

**Failure 1:**
- Message: Target has insufficient size and spacing
- HTML: `<a title="Vai a pagina 2" href="/it/gallerie-governo?page=1">2</a>`
- XPath: `/a`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h6">Foto                    </p>`
- XPath: `/p[@class="h6"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h2 class="h4">PNRR, Cabina di regia su interventi Comuni, Città ...</h2>`
- XPath: `/h2[@class="h4"]`

**Failure 2:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/articolo/il-messaggio-del-presidente-meloni-lanniversario-della-costituzione-di-confetra/31195

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R2: HTML elements have a valid lang attribute](https://alfa.siteimprove.com/rules/sia-r2)

**Failure 1:**
- Message: The image does not have an accessible name
- HTML: `<img class="width_100" src="https://www.governo.it/sites/governo.it/files/B7A915CA3A27_pp%20%281%29.jpg" />`
- XPath: `/img[@class="width_100"]`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R61](https://alfa.siteimprove.com/rules/sia-r61)

**Failure 1:**
- Message: The document does not start with a level 1 heading

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 2.27:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h6">Giovedì, 26 Febbraio 2026</p>`
- XPath: `/p[@class="h6"]`

#### Rule: [SIA-R74](https://alfa.siteimprove.com/rules/sia-r74)

**Failure 1:**
- Message: The font size is specified using an absolute unit
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

### https://governo.it/it/articolo/il-sottosegretario-mantovano-partecipa-allinaugurazione-dell-anno-giudiziario-della-corte

#### Rule: [SIA-R11: Button elements have an accessible name](https://alfa.siteimprove.com/rules/sia-r11)

**Failure 1:**
- Message: The link does not have an accessible name
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">...</a>`
- XPath: `/a[@class="toggle-menu menu-left push-body jPushMenuBtn"]`

#### Rule: [SIA-R111: Interactive elements have a sufficient target size](https://alfa.siteimprove.com/rules/sia-r111)

**Failure 1:**
- Message: Target has insufficient size
- HTML: `<button type="button" class="find-more-button eu-cookie-compliance-more-button find-more-button-processed">Più informazioni</button>`
- XPath: `/button[@class="find-more-button eu-cookie-compliance-more-button find-more-button-processed"]`

**Failure 2:**
- Message: Target has insufficient size
- HTML: `<a href="https://www.governo.it">IT</a>`
- XPath: `/a`

#### Rule: [SIA-R2: HTML elements have a valid lang attribute](https://alfa.siteimprove.com/rules/sia-r2)

**Failure 1:**
- Message: The image does not have an accessible name
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/logo_PCM_7_25_3.png?itok=rJ1_TsA7" />`
- XPath: `/img`

#### Rule: [SIA-R53: Headings follow a logical hierarchy](https://alfa.siteimprove.com/rules/sia-r53)

**Failure 1:**
- Message: The heading skips one or more levels
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R57: Landmarks don't repeat the same content](https://alfa.siteimprove.com/rules/sia-r57)

**Failure 1:**
- Message: The text is not included in a landmark region

#### Rule: [SIA-R66: Text has enhanced contrast with its background](https://alfa.siteimprove.com/rules/sia-r66)

**Failure 1:**
- Message: The highest possible contrast of the text is 5.57:1 which is         below the required contrast of 7:1

#### Rule: [SIA-R69: Text has sufficient contrast with its background](https://alfa.siteimprove.com/rules/sia-r69)

**Failure 1:**
- Message: The highest possible contrast of the text is 3.17:1 which is         below the required contrast of 4.5:1

#### Rule: [SIA-R72](https://alfa.siteimprove.com/rules/sia-r72)

**Failure 1:**
- Message: The text of the paragraph is uppercased
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

#### Rule: [SIA-R73: Text spacing can be adjusted without loss of content](https://alfa.siteimprove.com/rules/sia-r73)

**Failure 1:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="menu_under_burger">MENU</p>`
- XPath: `/p[@class="menu_under_burger"]`

**Failure 2:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="nav_social clearfix">...</p>`
- XPath: `/p[@class="nav_social clearfix"]`

**Failure 3:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p class="h5 dataright">24 Febbraio 2026</p>`
- XPath: `/p[@class="h5 dataright"]`

**Failure 4:**
- Message: The line height of the paragraph is less than 1.5
- HTML: `<p>...</p>`
- XPath: `/p`

#### Rule: [SIA-R78: Headings of same level have text content between them](https://alfa.siteimprove.com/rules/sia-r78)

**Failure 1:**
- Message: There is no content between this heading and the next
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `/h3[@class="contacts_footer"]`

#### Rule: [SIA-R83: Text can be resized to 200% without loss of content](https://alfa.siteimprove.com/rules/sia-r83)

**Failure 1:**
- Message: The text is clipped

#### Rule: [SIA-R84](https://alfa.siteimprove.com/rules/sia-r84)

**Failure 1:**
- Message: The scrollable element is not reachable through keyboard navigation
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">...</nav>`
- XPath: `/nav[@class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left"]`

## Detailed Failure Information (axe)

### https://governo.it/

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [image-alt](https://dequeuniversity.com/rules/axe/4.11/image-alt?application=playwright)
**Impact**: critical

**Failure 1:**
- Message: Images must have alternative text
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/field/image/h_20260228_6.jpg?itok=P9rqZJ9u" class="class_img_url_immagine">`
- XPath: `.first_node.slides_home.img_contorno > .class_img_url_immagine`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

**Failure 2:**
- Message: Links must have discernible text
- HTML: `<a href=""><img class="banner_corona_home_img" src="https://www.governo.it/" alt=""><span class="banner_corona_home_span"></span></a>`
- XPath: `.col-md-4:nth-child(1) > .banner_corona_home > a[href=""]`

**Failure 3:**
- Message: Links must have discernible text
- HTML: `<a href=""><img class="banner_corona_home_img" src="https://www.governo.it/" alt=""><span class="banner_corona_home_span"></span></a>`
- XPath: `.col-md-4:nth-child(3) > .banner_corona_home > a[href=""]`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/en

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contacts</h3>`
- XPath: `.contacts_footer`

#### Rule: [image-alt](https://dequeuniversity.com/rules/axe/4.11/image-alt?application=playwright)
**Impact**: critical

**Failure 1:**
- Message: Images must have alternative text
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/field/image/h_20260228_6.jpg?itok=P9rqZJ9u" class="class_img_url_immagine">`
- XPath: `.first_node.slides_home.img_contorno > .class_img_url_immagine`

#### Rule: [image-redundant-alt](https://dequeuniversity.com/rules/axe/4.11/image-redundant-alt?application=playwright)
**Impact**: minor

**Failure 1:**
- Message: Alternative text of images should not be repeated as text
- HTML: `<img class="banner_corona_home_img" src="https://www.governo.it/sites/governo.it/files/italia_domani_HP_0.png" alt="NRRP website">`
- XPath: `img[alt="NRRP website"]`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Search" placeholder="Search..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

**Failure 2:**
- Message: Links must have discernible text
- HTML: `<a href=""><img class="banner_corona_home_img" src="https://www.governo.it/" alt=""><span class="banner_corona_home_span"></span></a>`
- XPath: `a[href=""]`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [image-alt](https://dequeuniversity.com/rules/axe/4.11/image-alt?application=playwright)
**Impact**: critical

**Failure 1:**
- Message: Images must have alternative text
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/field/image/h_20260228_6.jpg?itok=P9rqZJ9u" class="class_img_url_immagine">`
- XPath: `.first_node.slides_home.img_contorno > .class_img_url_immagine`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

**Failure 2:**
- Message: Links must have discernible text
- HTML: `<a href=""><img class="banner_corona_home_img" src="https://www.governo.it/" alt=""><span class="banner_corona_home_span"></span></a>`
- XPath: `.col-md-4:nth-child(1) > .banner_corona_home > a[href=""]`

**Failure 3:**
- Message: Links must have discernible text
- HTML: `<a href=""><img class="banner_corona_home_img" src="https://www.governo.it/" alt=""><span class="banner_corona_home_span"></span></a>`
- XPath: `.col-md-4:nth-child(3) > .banner_corona_home > a[href=""]`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/pubblicit%C3%A0-legale

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/feed/rss

#### Rule: [document-title](https://dequeuniversity.com/rules/axe/4.11/document-title?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Documents must have <title> element to aid in navigation
- HTML: `<html>`
- XPath: `html`

#### Rule: [html-has-lang](https://dequeuniversity.com/rules/axe/4.11/html-has-lang?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: <html> element must have a lang attribute
- HTML: `<html>`
- XPath: `html`

#### Rule: [landmark-one-main](https://dequeuniversity.com/rules/axe/4.11/landmark-one-main?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Document should have one main landmark
- HTML: `<html>`
- XPath: `html`

#### Rule: [page-has-heading-one](https://dequeuniversity.com/rules/axe/4.11/page-has-heading-one?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Page should contain a level-one heading
- HTML: `<html>`
- XPath: `html`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<pre style="word-wrap: break-word; white-space: pre-wrap;">`
- XPath: `pre`

### https://governo.it/it/agenda

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/agenda?t_p=h

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/archivio-articoli-presidenza-del-consiglio

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/archivio-consiglio-dei-ministri

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/campagne-di-comunicazione

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/come-fare

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/comitati-commissioni-e-commissari

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/comitati-commissioni-e-commissari">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/comitati-commissioni-e-commissari">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 2:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a href="http://www.commissioneaccesso.it/">sito web</a>`
- XPath: `ul:nth-child(5) > li:nth-child(1) > a`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

**Failure 2:**
- Message: Links must have discernible text
- HTML: `<a href="https://presidenza.governo.it/AmministrazioneTrasparente/Organizzazione/CommissariStraordinari/DPR_20250113_Castelli.pdf">&nbsp;</a>`
- XPath: `li:nth-child(4) > a:nth-child(2)`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/dichiarazioneaccessibilita

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/accessibility-statement">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/accessibility-statement">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 2:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a href="mailto:accessibile@governo.it">accessibile@governo.it</a>`
- XPath: `a[href="mailto:accessibile@governo.it"]`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/diretta-video

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/live-video-broadcast">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [frame-title](https://dequeuniversity.com/rules/axe/4.11/frame-title?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Frames must have an accessible name
- HTML: `<iframe width="1232" height="693" src="https://www.youtube.com/embed/bm77mn8H5SI" frameborder="0" allowfullscreen=""></iframe>`
- XPath: `iframe`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3>Gli altri video</h3>`
- XPath: `.col-md-6.col-sm-6:nth-child(1) > h3`

**Failure 2:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/live-video-broadcast">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/gallerie-del-presidente

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/palazzo-chigi-la-storia-le-immagini-e-il-restauro/palazzo-chigi-la-storia/2877

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/palazzo-chigi/17390">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [landmark-unique](https://dequeuniversity.com/rules/axe/4.11/landmark-unique?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Landmarks should have a unique role or role/label/title (i.e. accessible name) combination
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">`
- XPath: `.cbp-spmenu`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/palazzo-chigi/17390">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/articolo/il-messaggio-del-presidente-meloni-all-evento-ia-e-lavoro-governare-la-trasformazione

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/articolo/president-meloni-s-message-event-ai-and-work-managing-transformation-multiplying">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [image-alt](https://dequeuniversity.com/rules/axe/4.11/image-alt?application=playwright)
**Impact**: critical

**Failure 1:**
- Message: Images must have alternative text
- HTML: `<img class="width_100" src="https://www.governo.it/sites/governo.it/files/PresidenteMeloni%20%283%29.jpg">`
- XPath: `.width_100`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/articolo/president-meloni-s-message-event-ai-and-work-managing-transformation-multiplying">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/gallerie

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/articolo/la-facciata-di-palazzo-chigi-si-illumina-il-quarto-anniversario-dellinvasione-dellucraina

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [frame-title](https://dequeuniversity.com/rules/axe/4.11/frame-title?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Frames must have an accessible name
- HTML: `<iframe frameborder="0" src="https://www.youtube-..." id="fitvid189371">`
- XPath: `#fitvid189371`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/pubblicita-legale

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/media/campagna-di-comunicazione-istituzionale-il-treno-del-ricordo-2026/31082

#### Rule: [aria-prohibited-attr](https://dequeuniversity.com/rules/axe/4.11/aria-prohibited-attr?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must only use permitted ARIA attributes
- HTML: `<div class="html5-video-player ytp-hide-controls ytp-exp-bottom-control-flexbox ytp-modern-caption ytp-livebadge-color unstarted-mode" tabindex="" id="movie_player" data-version="/s/player/00c52fa0/player_embed.vflset/en_US/base.js" aria-label="YouTube Video Player">`
- XPath: `iframe`

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/media/la-facciata-di-palazzo-chigi-si-illumina-il-quarto-anniversario-dellinvasione-dellucraina-0

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [frame-title](https://dequeuniversity.com/rules/axe/4.11/frame-title?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Frames must have an accessible name
- HTML: `<iframe class="" width="640" height="360" src="//www.youtube-nocook..." frameborder="0" allowfullscreen="">`
- XPath: `iframe`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/provvedimenti

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="h4">`
- XPath: `.views-row-1 > .box_text_archive.box_text.clearfix > .h4`

**Failure 2:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/tipologie-contenuto/notizie

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="h4"><a href="/it/node/31220" title="Leggi l'articolo Middle East: President Meloni chairs meeting at Palazzo Chigi">Middle East: President Meloni chairs meeting at Palazzo Chigi</a></h3>`
- XPath: `.views-row-1 > .box_text_archive.box_text.clearfix > .h4`

**Failure 2:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/media/la-facciata-di-palazzo-chigi-si-illumina-il-quarto-anniversario-dellinvasione-dellucraina

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/governo/meloni/presidente-del-consiglio/giorgia-meloni

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/governo/meloni/president-council-ministers/giorgia-meloni">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/governo/meloni/president-council-ministers/giorgia-meloni">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/notizie-governo

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/organizzazione/il-segretario-generale/64

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/secretary-general/11964">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [landmark-unique](https://dequeuniversity.com/rules/axe/4.11/landmark-unique?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Landmarks should have a unique role or role/label/title (i.e. accessible name) combination
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">`
- XPath: `.cbp-spmenu`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/secretary-general/11964">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/il-governo-funzioni-struttura-e-storia/la-funzione-del-presidente-del-consiglio/188

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/prime-minister/11813">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [landmark-unique](https://dequeuniversity.com/rules/axe/4.11/landmark-unique?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Landmarks should have a unique role or role/label/title (i.e. accessible name) combination
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">`
- XPath: `.cbp-spmenu`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/prime-minister/11813">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/articolo/incidente-milano-il-cordoglio-del-presidente-meloni/31213

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/articolo/president-meloni-s-condolence-message-following-incident-milan/31214">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [image-alt](https://dequeuniversity.com/rules/axe/4.11/image-alt?application=playwright)
**Impact**: critical

**Failure 1:**
- Message: Images must have alternative text
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/BD8E879E_PP.jpg?itok=NuB9_Mmu">`
- XPath: `.thumb_container > img`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/articolo/president-meloni-s-condolence-message-following-incident-milan/31214">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/il-presidente

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/president">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="h4"><a class="simple-link-blu" href="https://www.governo.it/it/governo/meloni/presidente-del-consiglio/giorgia-meloni" title="Biografia">Biografia</a></h3>`
- XPath: `.col-md-3:nth-child(1) > .box_text_context.box_text.clearfix > .h4`

**Failure 2:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/president">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 2:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a href="mailto:presidente@pec.governo.it">presidente@pec.governo.it</a>`
- XPath: `.box_text_context.box_text.clearfix > p:nth-child(3) > a`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/notizie-presidente

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/organizzazione/uffici-dipartimenti-strutture/69

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/offices-departments-and-committees/11986">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [landmark-unique](https://dequeuniversity.com/rules/axe/4.11/landmark-unique?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Landmarks should have a unique role or role/label/title (i.e. accessible name) combination
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">`
- XPath: `.cbp-spmenu`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/offices-departments-and-committees/11986">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 2:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a href="http://www.sspa.it/">Scuola Nazionale dell'Amministrazione</a>`
- XPath: `a[href$="sspa.it/"]`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/articolo/giorno-del-ricordo-dal-10-febbraio-al-1-marzo-2026-la-3a-edizione-del-treno-del-ricordo

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [image-alt](https://dequeuniversity.com/rules/axe/4.11/image-alt?application=playwright)
**Impact**: critical

**Failure 1:**
- Message: Images must have alternative text
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/H_IMG_0798.jpg?itok=gEwWwQ8c">`
- XPath: `.thumb_container > img`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/visitare-i-palazzi-istituzionali/prenotazione-visite-guidate/2939

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/visiting-institutional-palaces/guided-tours/11889">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [landmark-unique](https://dequeuniversity.com/rules/axe/4.11/landmark-unique?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Landmarks should have a unique role or role/label/title (i.e. accessible name) combination
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">`
- XPath: `.cbp-spmenu`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/visiting-institutional-palaces/guided-tours/11889">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/agenda/2026-03-04t000000/laying-groundwork-jobs-africa/31205

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/piano-mattei

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [landmark-unique](https://dequeuniversity.com/rules/axe/4.11/landmark-unique?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Landmarks should have a unique role or role/label/title (i.e. accessible name) combination
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">`
- XPath: `.cbp-spmenu`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a href="/node/24851">Vertice Italia-Africa del 29 gennaio 2024</a>`
- XPath: `a[href="/node/24851"]`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

**Failure 2:**
- Message: Links must have discernible text
- HTML: `<a href="#" title="" class="share_buttons_trigger reveal-trigger" tabindex="-1"><span class="icon icon-sharethis" aria-hidden="true"></span></a>`
- XPath: `.share_buttons_trigger`

#### Rule: [listitem](https://dequeuniversity.com/rules/axe/4.11/listitem?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: <li> elements must be contained in a <ul> or <ol>
- HTML: `<li id="li_1" class="h5 li_menu_eventi"><a class="eventi eventi_active" href="/it/piano-mattei">Il Piano Mattei per l'Africa</a></li>`
- XPath: `#li_1`

**Failure 2:**
- Message: <li> elements must be contained in a <ul> or <ol>
- HTML: `<li id="li_2" class="h5 li_menu_eventi"><a class="eventi eventi_no_active" href="/it/articolo/piano-mattei-lafrica-obiettivi-e-settori-di-intervento/28739">Obiettivi e settori di intervento</a></li>`
- XPath: `#li_2`

**Failure 3:**
- Message: <li> elements must be contained in a <ul> or <ol>
- HTML: `<li id="li_3" class="h5 li_menu_eventi"><a class="eventi eventi_no_active" href="/it/articolo/piano-mattei-lafrica-la-cabina-di-regia/28742">La Cabina di Regia</a></li>`
- XPath: `#li_3`

**Failure 4:**
- Message: <li> elements must be contained in a <ul> or <ol>
- HTML: `<li id="li_4" class="h5 li_menu_eventi"><a class="eventi eventi_no_active" href="/it/articolo/piano-mattei-lafrica-la-struttura-di-missione/28743">La Struttura di Missione</a></li>`
- XPath: `#li_4`

**Failure 5:**
- Message: <li> elements must be contained in a <ul> or <ol>
- HTML: `<li id="li_5" class="h5 li_menu_eventi"><a class="eventi eventi_no_active" href="/it/articolo/piano-mattei-lafrica-la-relazione-annuale-al-parlamento/28746">La Relazione annuale al Parlamento</a></li>`
- XPath: `#li_5`

*... and 2 more failures for this rule*

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/i-ministeri-0

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h4 class="strong">Presidenza del Consiglio dei Ministri</h4>`
- XPath: `.strong:nth-child(3)`

**Failure 2:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

**Failure 2:**
- Message: Links must have discernible text
- HTML: `<a href="mailto:gabinetto.rapportiparlamento@governo.it%20%20%20"><strong>&nbsp;</strong></a>`
- XPath: `p:nth-child(23) > a:nth-child(4)`

**Failure 3:**
- Message: Links must have discernible text
- HTML: `<a href="http://www.difesa.it/SMD_/"> </a>`
- XPath: `a[href$="SMD_/"]`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/media/incontro-con-il-presidente-della-repubblica-di-cipro/31198

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/media/meeting-president-republic-cyprus/31201">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [frame-title](https://dequeuniversity.com/rules/axe/4.11/frame-title?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Frames must have an accessible name
- HTML: `<iframe class="" width="640" height="360" src="//www.youtube-nocook..." frameborder="0" allowfullscreen="">`
- XPath: `.even.field-item:nth-child(1) > .field-collection-view.view-mode-full.clearfix > .entity.entity-field-collection-item.field-collection-item-field-video-collection > .content > .field-name-field-video.field-type-video-embed-field.field-label-hidden > .field-items > .even.field-item > .embedded-video > .player > .fluid-width-video-wrapper > iframe`

**Failure 2:**
- Message: Frames must have an accessible name
- HTML: `<iframe class="" width="640" height="360" src="//www.youtube-nocook..." frameborder="0" allowfullscreen="">`
- XPath: `.odd > .field-collection-view.view-mode-full.clearfix > .entity.entity-field-collection-item.field-collection-item-field-video-collection > .content > .field-name-field-video.field-type-video-embed-field.field-label-hidden > .field-items > .even.field-item > .embedded-video > .player > .fluid-width-video-wrapper > iframe`

**Failure 3:**
- Message: Frames must have an accessible name
- HTML: `<iframe class="" width="640" height="360" src="//www.youtube-nocook..." frameborder="0" allowfullscreen="">`
- XPath: `.field-collection-view-final > .entity.entity-field-collection-item.field-collection-item-field-video-collection > .content > .field-name-field-video.field-type-video-embed-field.field-label-hidden > .field-items > .even.field-item > .embedded-video > .player > .fluid-width-video-wrapper > iframe`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/media/meeting-president-republic-cyprus/31201">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/articolo/consiglio-dei-ministri-n-163/31194

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [image-alt](https://dequeuniversity.com/rules/axe/4.11/image-alt?application=playwright)
**Impact**: critical

**Failure 1:**
- Message: Images must have alternative text
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/palazzo_chigi_22_6.jpg?itok=_mAwl-Yw">`
- XPath: `.thumb_container > img`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/ministri-e-sottosegretari

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/ministers-and-undersecretaries">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h4>Presidente del Consiglio dei Ministri</h4>`
- XPath: `.box_text_with_thumb.box_text.clearfix > h4`

**Failure 2:**
- Message: Heading levels should only increase by one
- HTML: `<h3 style="margin-bottom: 0px;">Ministro per i Rapporti con il Parlamento</h3>`
- XPath: `.half_base.row:nth-child(7) > .col-md-8 > h3`

**Failure 3:**
- Message: Heading levels should only increase by one
- HTML: `<h3 style="margin-bottom: 0px;">Ministero degli Affari Esteri e della Cooperazione Internazionale</h3>`
- XPath: `.half_base.row:nth-child(36) > .col-md-8 > h3`

**Failure 4:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/ministers-and-undersecretaries">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/articolo/tre-anni-di-governo-meloni-tre-anni-di-risultati-e-traguardi-l-italia/30114

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/articolo/three-years-meloni-government-three-years-achievements-and-milestones-italy/30116">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [image-alt](https://dequeuniversity.com/rules/axe/4.11/image-alt?application=playwright)
**Impact**: critical

**Failure 1:**
- Message: Images must have alternative text
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/notizia-3-anni.png?itok=pqAVElsr">`
- XPath: `.thumb_container > img`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/articolo/three-years-meloni-government-three-years-achievements-and-milestones-italy/30116">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/costituzione-italiana/principi-fondamentali/2839

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/fundamental-principles/11825">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [landmark-unique](https://dequeuniversity.com/rules/axe/4.11/landmark-unique?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Landmarks should have a unique role or role/label/title (i.e. accessible name) combination
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">`
- XPath: `.cbp-spmenu`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/fundamental-principles/11825">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/media/corinaldo-incontro-con-i-familiari-delle-vittime-palazzo-chigi/31211

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/agenda/2026-03-06t000000/cerimonia-di-apertura-dei-giochi-paralimpici-invernali-di-milano-cortina

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/media/giorno-del-ricordo-dal-10-febbraio-al-1-marzo-2026-la-3a-edizione-del-treno-del-ricordo/31177

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/media/cerimonia-di-chiusura-dei-giochi-olimpici-invernali-di-milano-cortina-2026/31175

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/media/milano-cortina-2026-winter-olympic-games-closing-ceremony/31185">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/media/milano-cortina-2026-winter-olympic-games-closing-ceremony/31185">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/il-governo

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/government">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h5><a href="https://www.governo.it/it/approfondimento/otto-mille/3694">Otto per mille</a></h5>`
- XPath: `h5`

**Failure 2:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [landmark-unique](https://dequeuniversity.com/rules/axe/4.11/landmark-unique?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Landmarks should have a unique role or role/label/title (i.e. accessible name) combination
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">`
- XPath: `.cbp-spmenu`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/government">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/agenda/2026-02-27t000000/voto-alle-donne/31206

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/media/riunione-della-coalizione-dei-volenterosi/31181

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/media/meeting-coalition-willing/31183">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/media/meeting-coalition-willing/31183">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/media/incontro-con-il-presidente-della-repubblica-di-cipro/31200

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/media/meeting-president-republic-cyprus/31203">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/media/meeting-president-republic-cyprus/31203">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/il-governo-funzioni-struttura-e-storia/la-struttura-del-governo/185

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [landmark-unique](https://dequeuniversity.com/rules/axe/4.11/landmark-unique?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Landmarks should have a unique role or role/label/title (i.e. accessible name) combination
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">`
- XPath: `.cbp-spmenu`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/privacy-policy

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/privacy-policy">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/privacy-policy">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 2:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a href="/it">www.governo.it</a>`
- XPath: `p:nth-child(2) > a[href="/it"]`

**Failure 3:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a href="https://www.google.it/intl/it/policies/privacy/">https://www.google.it/intl/it/policies/privacy/</a>`
- XPath: `ul:nth-child(25) > li:nth-child(2) > a`

**Failure 4:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a href="https://support.google.com/analytics/answer/6004245">https://support.google.com/analytics/answer/6004245</a>`
- XPath: `li:nth-child(3) > a:nth-child(2)`

**Failure 5:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a href="https://support.google.com/analytics/answer/2763052?hl=it&amp;ref_topic=2919631">consente di mascherare gli indirizzi IP</a>`
- XPath: `li:nth-child(3) > a:nth-child(3)`

*... and 4 more failures for this rule*

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/tipologie-contenuto/consiglio-dei-ministri

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="h4"><a href="/it/articolo/consiglio-dei-ministri-n-163/31194" title="Leggi l'articolo Consiglio dei Ministri n. 163">Consiglio dei Ministri n. 163</a></h3>`
- XPath: `.views-row-1 > .box_text_archive.box_text.clearfix > .h4`

**Failure 2:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/i-governi-dal-1943-ad-oggi/i-governi-nelle-legislature/192

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [landmark-unique](https://dequeuniversity.com/rules/axe/4.11/landmark-unique?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Landmarks should have a unique role or role/label/title (i.e. accessible name) combination
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">`
- XPath: `.cbp-spmenu`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/note-legali

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/note-legali">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/note-legali">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 2:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a href="/it">www.governo.it</a>`
- XPath: `p:nth-child(2) > a[href="/it"]`

**Failure 3:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a href="http://creativecommons.org/licenses/by/3.0/it/legalcode">http://creativecommons.org/licenses/by/3.0/it/legalcode</a>`
- XPath: `p:nth-child(7) > a`

**Failure 4:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a href="mailto:notelegali@governo.it">notelegali@governo.it</a>`
- XPath: `a[href="mailto:notelegali@governo.it"]`

**Failure 5:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a href="https://www.governo.it/privacy-policy">Informativa sulla Privacy</a>`
- XPath: `p:nth-child(19) > a:nth-child(1)`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/agenda/2026-03-04t000000/incontro-con-il-ministro-degli-esteri-degli-emirati-arabi-uniti/31207

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/articolo/corinaldo-incontro-con-i-familiari-delle-vittime-palazzo-chigi/31212

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [image-alt](https://dequeuniversity.com/rules/axe/4.11/image-alt?application=playwright)
**Impact**: critical

**Failure 1:**
- Message: Images must have alternative text
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/H_DSC09689.jpg?itok=ogq_xTuw">`
- XPath: `.thumb_container > img`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/articolo/g7-leaders-statement-war-ukraine/31186

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/articolo/g7-leaders-statement-war-ukraine/31191">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [image-alt](https://dequeuniversity.com/rules/axe/4.11/image-alt?application=playwright)
**Impact**: critical

**Failure 1:**
- Message: Images must have alternative text
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/logo_PCM_136.png?itok=mxVl33xN">`
- XPath: `.thumb_container > img`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/articolo/g7-leaders-statement-war-ukraine/31191">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/la-presidenza-del-consiglio-dei-ministri

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/presidency-council-ministers">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h5><a href="https://www.governo.it/it/approfondimento/otto-mille/3694">Otto per mille</a></h5>`
- XPath: `h5`

**Failure 2:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [landmark-unique](https://dequeuniversity.com/rules/axe/4.11/landmark-unique?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Landmarks should have a unique role or role/label/title (i.e. accessible name) combination
- HTML: `<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">`
- XPath: `.cbp-spmenu`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/presidency-council-ministers">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/articolo/medio-oriente-il-presidente-meloni-presiede-una-conferenza-telefonica/31215

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/articolo/middle-east-president-meloni-chairs-conference-call/31216">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [image-alt](https://dequeuniversity.com/rules/axe/4.11/image-alt?application=playwright)
**Impact**: critical

**Failure 1:**
- Message: Images must have alternative text
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/logo_PCM_128_2.png?itok=HJMSujGB">`
- XPath: `.thumb_container > img`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/articolo/middle-east-president-meloni-chairs-conference-call/31216">English</a>`
- XPath: `.lingua_non_corrente`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/notizie-presidenza

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/notizie-chigi

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/interventi

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/sala-stampa

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/sala-stampa">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 3:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-in-text-block](https://dequeuniversity.com/rules/axe/4.11/link-in-text-block?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a class="lingua_non_corrente" href="https://www.governo.it/en/sala-stampa">English</a>`
- XPath: `.lingua_non_corrente`

**Failure 2:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a href="https://amei.palazzochigi.it">https://amei.palazzochigi.it</a>`
- XPath: `p:nth-child(2) > a[href$="amei.palazzochigi.it"]`

**Failure 3:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a href="https://amei.palazzochigi.it" style="line-height: 20.8px;">https://amei.palazzochigi.it</a>`
- XPath: `p:nth-child(3) > a[href$="amei.palazzochigi.it"]`

**Failure 4:**
- Message: Links must be distinguishable without relying on color
- HTML: `<a href="/it/agenda">Agenda</a>`
- XPath: `p:nth-child(4) > a[href$="agenda"]`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/gallerie-governo

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/articolo/il-messaggio-del-presidente-meloni-lanniversario-della-costituzione-di-confetra/31195

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [image-alt](https://dequeuniversity.com/rules/axe/4.11/image-alt?application=playwright)
**Impact**: critical

**Failure 1:**
- Message: Images must have alternative text
- HTML: `<img class="width_100" src="https://www.governo.it/sites/governo.it/files/B7A915CA3A27_pp%20%281%29.jpg">`
- XPath: `.width_100`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

### https://governo.it/it/articolo/il-sottosegretario-mantovano-partecipa-allinaugurazione-dell-anno-giudiziario-della-corte

#### Rule: [color-contrast](https://dequeuniversity.com/rules/axe/4.11/color-contrast?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<strong> Privacy policy</strong>`
- XPath: `u > strong`

**Failure 2:**
- Message: Elements must meet minimum color contrast ratio thresholds
- HTML: `<span>Condividi</span>`
- XPath: `.share_buttons > span`

#### Rule: [heading-order](https://dequeuniversity.com/rules/axe/4.11/heading-order?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: Heading levels should only increase by one
- HTML: `<h3 class="contacts_footer">Contatti</h3>`
- XPath: `.contacts_footer`

#### Rule: [image-alt](https://dequeuniversity.com/rules/axe/4.11/image-alt?application=playwright)
**Impact**: critical

**Failure 1:**
- Message: Images must have alternative text
- HTML: `<img src="https://www.governo.it/sites/governo.it/files/styles/860x600/public/logo_PCM_7_25_3.png?itok=rJ1_TsA7">`
- XPath: `.thumb_container > img`

#### Rule: [label-title-only](https://dequeuniversity.com/rules/axe/4.11/label-title-only?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Form elements should have a visible label
- HTML: `<input class="form-control" type="text" value="" name="search_block_form" title="Cerca nel sito" placeholder="Cerca..." id="form-search-input">`
- XPath: `#form-search-input`

#### Rule: [link-name](https://dequeuniversity.com/rules/axe/4.11/link-name?application=playwright)
**Impact**: serious

**Failure 1:**
- Message: Links must have discernible text
- HTML: `<a href="#" class="toggle-menu menu-left push-body jPushMenuBtn">                         <div class="bar"></div>                         <div class="bar"></div>                         <div class="bar"></div>                     </a>`
- XPath: `.toggle-menu`

#### Rule: [region](https://dequeuniversity.com/rules/axe/4.11/region?application=playwright)
**Impact**: moderate

**Failure 1:**
- Message: All page content should be contained by landmarks
- HTML: `<p>`
- XPath: `#popup-text > p`

**Failure 2:**
- Message: All page content should be contained by landmarks
- HTML: `<p id="skip-link">         <a href="#main" class="element_invisible element_focusable">Vai al Contenuto</a>         <a href="#footer" class="element_invisible element_focusable">Raggiungi il piè di pagina</a>     </p>`
- XPath: `#skip-link`

